<?php
ini_set('default_charset', 'utf-8');
echo '<h1> Шаблон перенесен !!! <br> Скоро ссылка уберется и для просмотра шаблона нужно будет перейти :'
. '<br>flc-bookclub.com/assets/'
        . '</h1>';
?>
<a href="/assets/"> Жми сюда </a>

<?php 
	/*echo '<pre>';
	print_r($_SERVER);
	echo '</pre>';*/
	
	
$uri_site = $_SERVER['REQUEST_URI'];
if (strpos($uri_site, '?') !== false) {
	$uri_site = trim(substr($uri_site, 0, strpos($uri_site, '?')), '/');
} /*elseif (strrpos($uri_site, '/') != strlen($uri_site) - 1) {
	$uri_site .= '/';
}*/
print_r($uri_site);
	
	
?>

