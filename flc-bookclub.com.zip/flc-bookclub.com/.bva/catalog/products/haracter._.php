<?php
//*
ini_set('display_errors',1);
error_reporting(E_ALL);
//*/ 
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
	$id = $_GET['id'];
} else {
	die('Не введено ID товара');
}
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	if (isset($_POST['delete'])) {
		$btvProduct->delProduct(array(0=>$id));
		header('Location: ./');
	}
	if (isset($_POST['save'])) {
		$paramArray = array();
		$paramArray['category_id'] = $_POST['category_id'];
		$paramArray['code'] = $_POST['code'];
		$paramArray['shortname_ru'] = $_POST['shortname_ru'];
		$paramArray['shortname_ua'] = $_POST['shortname_ua'];
		$paramArray['alias'] = $_POST['alias'];
		$paramArray['name_ru'] = $_POST['name_ru'];
		$paramArray['name_ua'] = $_POST['name_ua'];
		$paramArray['brief_ru'] = $_POST['brief_ru'];
		$paramArray['brief_ua'] = $_POST['brief_ua'];
		$paramArray['rng'] = $_POST['rng'];
		$paramArray['description_ru'] = $_POST['description_ru'];
		$paramArray['description_ua'] = $_POST['description_ua'];
		$paramArray['sircmd'] = isset($_POST['sircmd']) ? 1 : 0;
		$paramArray['si'] = isset($_POST['si']) ? 1 : 0;
		$btvProduct->changeProduct($paramArray, $id);
		$btvProduct->setTitles($id, $paramArray['code'], $_POST['title']);
	}
}
$dataArrayProduct = $btvProduct->getList(0, 1, array('pr.id' => $id), '');
$dataProduct = $dataArrayProduct[0];
$haractersProduct = $btvProduct->getHaracters($id);
print_r($haractersProduct);
//print_r($dataProduct);
$d1 = explode(' ', $haractersProduct['create_date']);
$d = explode('-', $d1[0]);
$create_data = $d[2] . '.' . $d[1] . '.' . $d[0] . ' ' . $d1[1];
$d1 = explode(' ', $haractersProduct['update_date']);
$d = explode('-', $d1[0]);
$update_data = $d[2] . '.' . $d[1] . '.' . $d[0] . ' ' . $d1[1];

$title_page = 'Характеристики товара Bottega';
include($admAbspth . 'layout/header.php');
?>
<script type="text/javascript">
<!--
$(function() {
	/*$('input[name="save"]').click(function() {
		var err = '';
		if (!$("#mainform input[name=shortname_ru]").val()) {
			err += ' \n - короткое наименование категории(рус.)';
		}
		if (!$("#mainform input[name=shortname_ua]").val()) {
			err += ' \n - короткое наименование категории(укр.)';
		}
		if (!$("#mainform input[name=name_ru]").val()) {
			err += ' \n - длинное наименование категории(рус.)';
		}
		if (!$("#mainform input[name=name_ua]").val()) {
			err += ' \n - длиное наименование категории(укр.)';
		}
		if (!$("#mainform input[name=alias]").val()) {
			err += ' \n - alias для категории';
		}
		if (err) {
			alert('Введите ' + err);
			return false;
		}
	});
	$('input[name="delete"]').click(function() {
		if (!confirm('Вы действительно хотите удалить товар?')) {
			return false;
		}
	});
	$('input[name="rng"]').keyup(function(e) {
		if (e.keyCode != 0x9) {
			var val = $(this).val().replace(/[^0-9]/g, '');
			$(this).val(val);
		}
	});*/
})

// -->
</script>
<!--Header begin-->
<?php include($admAbspth . 'layout/top.php'); ?>
<form action="./?p=edit&id=<?php echo $id; ?>" id="mainform" method="post" enctype="multipart/form-data">

<?php include($admAbspth . 'layout/buttons.php'); ?>

<!-- H1 -->
<hr>
<table cellpadding=0 cellspacing=0 border=0 width="100%">
	<tr>
<td width=42 nowrap><img src="/images/a/i-script-b.gif" width=42 height=32 alt="" border=0></td>
<td width="100%"><font size="+1"><b><?php echo $dataProduct['shortname_ru']; ?></b></font></td>
<td>

</td>
	</tr>
	<tr><td height=5></td></tr>
	<tr>
<td></td>
<td class=graysmall><?php  echo 'ID:&nbsp;'.$id.' '; 
if ($dataProduct['code']) echo '<span class="siteua">&nbsp;&nbsp; Code:&nbsp;'.$dataProduct['code'] . '</span>';
$allTitles = implode('<br>', $btvProduct->getTitles($id));
if ($allTitles) {echo '&nbsp;&nbsp; Titles: ' . $allTitles;}
?></td>
<td></td>
	</tr>	
	
	</table>

<!-- /H1 -->
<br>
<table width="100%" cellpadding=4 cellspacing=0 border=0 bgcolor=d4d4d4>
	<tr><td height=6></td></tr>
	<tr>
<td width=1><br></td>
<td bgcolor=ffffff nowrap>&nbsp;&nbsp;<a href="./?p=edit&id=<?php echo $id;?>">Описание</a>&nbsp;&nbsp;</td>
<td width=1><br></td>
<td bgcolor=f3f3f3 nowrap >&nbsp;&nbsp;<b>Характеристики</b>&nbsp;(<?php 
echo $btvProduct->getCountHaracters($id); 
?>)&nbsp;&nbsp;</td>
<td class="siteua" width=1><br></td>
<td class="siteua" bgcolor=f3f3f3 nowrap >&nbsp;&nbsp;<a href="./?p=price&id=<?php echo $id;?>">Цены&nbsp;(<?php 
echo $btvProduct->getCountPriceValues($id);
?>)</a>&nbsp;&nbsp;</td>
<td class="siteru" width=1><br></td>
<td width=1><br></td>
<td bgcolor=f3f3f3 nowrap >&nbsp;&nbsp;<a href="./?p=image&id=<?php echo $id;?>">Изображения&nbsp;(<?php 

echo $btvProduct->getCountImages($id); ?>)</td>


<td width=1><br></td>
<td width="100%" bgcolor=f3f3f3 nowrap align=right >
<?php /*
&nbsp;&nbsp;<a href="./comments/?f_pr=<?php echo $id;?>">Коммент.&nbsp;(<?php 

$r_pphotos=q_e("select ID from OOPCOMMENTS where OOPID=$id");
$nr_pphotos=q_nr($r_pphotos);

echo $nr_pphotos;?>)</a><?php 

$r_pphotos=q_e("select AVMARK from OOP2AVMARK where OOPID=$id");
$nr_pphotos=q_nr($r_pphotos);

if ($nr_pphotos>0) echo ',&nbsp;ср.&nbsp;оценка:&nbsp;'.q_r($r_pphotos,0,"AVMARK").'';

?> &nbsp;<a href="./comments/msgadd.html?pr=<?php echo $id;?>">+</a>&nbsp;&nbsp;*/ ?></td>
	</tr>
</table>
<!-- News brief -->
<table cellpadding=0 cellspacing=0 border=0 width="100%"><tr><td bgcolor=808080 valign=top>
<table cellpadding=4 cellspacing=1 border=0 width="100%">

 	<tr bgcolor=FFFDF2 valign=top>
		<td align=center width="3%"><b><font color="gray">ID</font></b></td>
		<td width="25%"><b>Название (рус. / укр.)</b></td>
		<td  align=left title="Значение (рус.)" width="5%"><b>Значение (рус.)</b></td>
		<td  align=left title="Значение (укр.)" width="5%"><b>Значение (укр.)</b></td>
		<td  align=left title="Коммент. (рус.)" width="5%"><b>Коммент. (рус.)</b></td>
		<td  align=left title="Коммент. (укр.)" width="5%"><b>Коммент. (укр.)</b></td>
		<td align=center width="5%"><img src="/images/a/i-order-b.gif" width=14 height=15 alt="Приоритет" border=0></td>
		<td  align=center title="Используется" width="5%"><b>Исп.</b></td>
	</tr>
	<tr bgcolor=f3f3f3 valign=top>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td align=center title="Отсортировано по приоритету"><img src="/images/a/i-arr.gif" width=7 height=4 border=0></td>
		<td></td>
	</tr>
<?php

$rowbgcolor="FFFFFF";
foreach ($haractersProduct as $h) { ?>
	<tr bgcolor="#<?php echo $rowbgcolor; ?>" valign=top>
		<td><?php echo $h['id']; ?></td>
		<td><?php echo $h['h_name_ru']; ?> / <?php echo $h['h_name_ua']; ?></td>
	</tr>
<?php	
if ($rowbgcolor=='FFFFFF') $rowbgcolor='F3F3F3'; else $rowbgcolor='FFFFFF';

}//foreach

//echo '<tr bgcolor="#'.$rowbgcolor.'" valign=top><td colspan=12><img src="/images/1.gif" width=1 height=1 border=0></td></tr>';

?>

</table>
</td></tr></table>
<div style="width: 100%; clear:both"><br /></div>

<?php 
//if (!$btvCat->checkCatOnParent($id)) {
	//$but_delete = 'Удалить товар';
//}
include($admAbspth . 'layout/buttons.php'); ?>

</form>
<?php include($admAbspth . 'layout/bottom.php'); ?>