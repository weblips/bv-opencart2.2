<?php
$error4msg='';
$paramFilter = array(); 
if (isset($_GET['i']) && is_numeric($_GET['i']) && $_GET['i']) {
	$i = $_GET['i'];
} else {
	$i = 0;
}
$p = 30;
$arrayGet = array();
if (isset($_GET['by']) && is_numeric($_GET['by']) && $_GET['by']) {
	$by = $_GET['by'];
	$arrayGet [] = 'by=' . $by;
	switch ($by) {
		case 9 :
			$order = 'pr.code';
			break;
		case 3 :
			$order = 'pr.name_ru';
			break;		
		case 4 :
			$order = 'cat.name_ru';
			break;
		case 2 :
			$order = 'pr.rng DESC';
			break;		
		case 5 :
			$order = 'pr.si DESC';
			break;	
		case 6 :
			$order = 'pr.sircmd DESC';
			break;	
		case 8 :
			$order = 'pr.o4m DESC';
			break;				
	}
} else {
	$by = 1;
	$order = 'pr.id DESC';
}
$f_id = $f_code = $f_name = $c_title = $f_category_id = $f_si = $f_o4m = '';
if (isset($_GET['filter'])) {
	if (isset($_GET['f_id'])) {
		$paramFilter['pr.id'] = $f_id = $_GET['f_id'];
		$arrayGet [] = 'f_id=' . $f_id;
	}
	if (isset($_GET['f_code'])) {
		$paramFilter['pr.code'] = $f_code = $_GET['f_code'];
		$arrayGet [] = 'f_code=' . $f_code;
	}
	if (isset($_GET['f_name'])) {
		$paramFilter['pr.name'] = $f_name = $_GET['f_name'];
		$arrayGet [] = 'f_name=' . $f_name;
	}
	if (isset($_GET['c_title'])) {
		$paramFilter['c.title'] = $c_title = $_GET['c_title'];
		$arrayGet [] = 'c_title=' . $c_title;
	}
	if (isset($_GET['f_category_id']) && $_GET['f_category_id']) {
		$paramFilter['pr.category_id'] = $f_category_id = $_GET['f_category_id'];
		$arrayGet [] = 'f_category_id=' . $f_category_id;
	}
	if (isset($_GET['f_si'])) {
		$paramFilter['pr.si'] = $f_si = $_GET['f_si'] == 2 ? 1 : 0;
		$arrayGet [] = 'f_si=' . $f_si;
	}
	if (isset($_GET['f_o4m'])) {
		$paramFilter['pr.o4m'] = $f_o4m = $_GET['f_o4m'] == 2 ? 1 : 0;
		$arrayGet [] = 'f_o4m=' . $f_o4m;
	}
}
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	//print_r($_POST);
	if ($_POST['shhi'])
	{
		//$idupfilesi_temp = $idupfile[$j];
		foreach ($_POST['idupfile'] as $v) {
			$param = array();
			$param['si'] = isset($_POST['idupfilesi']) && in_array($v, $_POST['idupfilesi']) ? 1 : 0;
			$param['sircmd'] = isset($_POST['idupfilercmd']) && in_array($v, $_POST['idupfilercmd']) ? 1 : 0;
			$param['o4m'] = isset($_POST['idupfileo4m']) && in_array($v, $_POST['idupfileo4m']) ? 1 : 0;
			$param['rng'] = $_POST['rngupfile'][$v];
			$btvProduct->changeProduct($param, $v);
		}
	//	cachePart::delete('menu/infotopmenu');
	//	cachePart::delete_ru('menu/infotopmenu');
	//	cachePart::delete('menu/specmenu');	
	}
}

$arrayProducts = $btvProduct->getList($i, $p, $paramFilter, $order);

/*echo '<pre>';
print_r($arrayProducts);
echo '</pre>';
*/
$handle=opendir("$abspth$imgpthg");
$j_normal = $total_dwndir_size = 0;
while ($file = readdir($handle)) {
	if ($file!='.' && $file!='..') {
		$j_normal++;
		$total_dwndir_size=$total_dwndir_size+filesize("$abspth$imgpthg$file");
	}
}
closedir($handle);

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
    <meta HTTP-EQUIV="Pragma" CONTENT="no-cache">
    <META HTTP-EQUIV="Expires" CONTENT="Mon, 01 Jan 2001 00:00:01 GMT">
    <title><?php echo $_SERVER["SERVER_NAME"];?> - Товары</title>
    <link rel="STYLESHEET" type="text/css" href="../../style/adm.css">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1251"></head>

<script language="JavaScript">
<!--

function rmTh(){
var fr = document.forms.thatform;
if(confirm('Удалить?')){
 fr.erth.value = 1;
 fr.action = ".";
 fr.submit();
}
}

function shTh(){
var fr = document.forms.thatform;
if(confirm('Спрятать / Показать?')){
 fr.shhi.value = 1;
 fr.action = ".";
 fr.submit();
}
}

function rngTh(){
var fr = document.forms.thatform;
if(confirm('Изменить приоритет?')){
 fr.rngth.value = 1;
 fr.action = ".";
 fr.submit();
}
}

function svTh(){
var fr = document.forms.thatform;
if(confirm('Сохранить изменения?')){
 fr.rngth.value = 1;
 fr.shhi.value = 1;
 fr.action = ".";
 fr.submit();
}
}

// -->
</script>

<body bgcolor="#f3f3f3" topMargin=0 leftMargin=0 marginheight=0 marginwidth=0><div align="center">

<!--Header begin-->
<table cellPadding=4 cellSpacing=0 border=0 width="100%" height=5>
        <tr>
<td bgcolor=#f3f3f3 valign="top">
<h2>Продукция</h2>

<a href="../">Центр управления</a> / Товары</td>
        </tr>
</table>
<!--Header end-->

<table width="100%" border=0 cellpadding=0 cellspacing=0 bgcolor="808080" height=1><td></td></table>






<!--Main table begin-->
<table cellPadding=4 cellSpacing=1 border=0 width="100%" bgcolor="#FFFFFF">
        <tr>




<?php include("../../_menu_bottega.php");?>

<!--Central col begin-->

<td width="100%" valign="top" bgcolor="#FFFFFF">


<!-- H1 -->
<hr>
<table cellpadding=0 cellspacing=0 border=0 width="100%">
        <tr>
<!-- <td width=38 nowrap><img src="/images/i-group-b.gif" width="28" height="28" alt="" border="0"><img src="/images/1.gif" width="10" height="28" alt="" border="0"></td> -->
<td width="100%"><font size="+1"><b>Товары</b></font><BR>
<?php echo '<font size="-2" color=gray>/images/db/goods/ <b>'.number_format(($total_dwndir_size / 1024),0,'','`')."</b>&nbsp;Kb в $j_normal файлах</font>";?>
</td>
<?php if($permision==2):?>
<td nowrap>
        <table cellpadding=4 cellspacing=0 border=0 bgcolor=f3f3f3 style="border: 1px solid #808080;">
                <tr>
        <td nowrap><a href=prodadd.html><img src="/images/a/i-file-add.gif" width=17 height=16 alt="Добавить новый товар" border=0 align=absmiddle hspace=4>Добавить новый товар</a></td>
        <!--<td>
               <p>
                   <button title="Переиндексация для поиска" class="reSph">
                       <img class="sph-node" src="/img/loupe_.png" alt="поиск" style="size: 30%; vertical-align: middle">ReIndex
                   </button>
               </p>
        </td>-->
                </tr>
        </table>
</td>
<?php endif; ?>	
        </tr>
</table>
<br>
<br>
<!-- /H1 -->

<form action="" method="get" name="filterform">
<input type="hidden" name="filter" value="1">
<!-- Filter -->
<table cellpadding=0 cellspacing=0 border=0 width="100%"><tr><td bgcolor=808080 valign=top>
<table cellpadding=4 cellspacing=1 border=0 width="100%">

        <tr bgcolor=f3f3f3 valign=top>
<td width="10%">
	ID:<br>
	<input type="text" size="5" name="f_id" class="form" value="<?php echo $f_id; ?>" />
</td>
<td width="10%">
	CODE:<br>
	<input type="text" size="5" name="f_code" class="form" value="<?php echo $f_code; ?>" />
</td>
<td width="15%">Название<br><input type="text" name="f_name" size="10" class="form" value="<?php echo $f_name; ?>" /></td>
<td width="15%">Тайтл:<br><input type="text" name="c_title" size="7" class="form" value="<?php echo $c_title; ?>" /></td>
<td width="40%" colspan=2>Группа товаров:<br>
<select name="f_category_id" class="form">
<option value=0>
	<?php foreach ($listCategories as $cat) : ?>
		<option value='<?php echo $cat['id']; ?>'
			<?php if (isset($f_category_id) && $f_category_id == $cat['id']) : 
				$category_name_ru = $cat['name_ru'];
			?>
				selected="selected"
			<?php endif; ?>
		><?php
			for($it = 0; $it < $cat['level']; $it ++) {
				echo '&mdash;';
			}
			echo $cat['name_ru']; ?>
		</option>
	<?php endforeach; ?>
</select>
</td>
<td nowrap width="20%"><span class="siteua">Видно:<br>
<input type="radio" value="2" id="f_si1" name="f_si" <?php echo $f_si == 1 ? 'checked' : ''; ?> OnMouseOver="javascript: if (filterform.f_si1.checked) {filterform.f_si1.checked=false;};"> да 
<input type="radio" value="1" id="f_si2" name="f_si" <?php echo $f_si === 0 ? 'checked' : ''; ?> OnMouseOver="javascript: if (filterform.f_si2.checked) {filterform.f_si2.checked=false;};">нет
</span>
</td>
        </tr>
    <tr bgcolor=f3f3f3>
        <td valign=top colspan=2>
        </td>
        <td valign=top>
			Только&nbsp;для&nbsp;ЧК:<br>
			<input type="radio" value="2" id="f_o4m1" name="f_o4m" <?php echo $f_o4m == 1 ? 'checked' : ''; ?> OnMouseOver="javascript: if (filterform.f_o4m1.checked) {filterform.f_o4m1.checked=false;};"> да 
			<input type="radio" value="1" id="f_o4m2" name="f_o4m"  <?php echo $f_o4m === 0 ? 'checked' : ''; ?>OnMouseOver="javascript: if (filterform.f_o4m2.checked) {filterform.f_o4m2.checked=false;};">нет
		</td>
        <td colspan="4" align="right"  ><input type="submit" value="Показать список товаров" class=button></td>
    </tr>

</table>
</td></tr></table>
<hr><br>
<!-- /Filter -->
</form>
<form action="" method="post" name="thatform">
<input type=hidden name=shhi value=0>
<input type=hidden name=erth value=0>
<input type=hidden name=rngth value=0>

<?php if ($error4msg) echo '<table width="100%" style="border:2px solid #ff9999;padding:5px;"><tr><td><font color="gray">'.$error4msg.'</font></td></tr></table><br>';?>

<font color="#808080">Показано:
<?php
$z = 0;
if ($f_id) {echo 'ID - <b>'.$f_id.'</b>'; $z=1;}
if ($f_code) {echo 'CODE - <b>'.$f_code.'</b>'; $z=1;}
if ($f_name) {if ($z) echo ', '; echo 'Название краткое - <b>'.$f_name.'</b>'; $z=1;}
if ($c_title) {if ($z) echo ', '; echo 'Тайтл - <b>'.$c_title.'</b>'; $z=1;}
if (isset($category_name_ru)) {
	if ($z) echo ', '; echo 'Группа товаров - <b>'.$category_name_ru.'</b>'; $z=1;
}

if ($f_si) {
	if ($z) echo ', ';
	if ($f_si==2) echo 'видно - <b>Да</b>';
	if ($f_si==1) echo 'видно - <b>Нет</b>';
	$z=1;
}
if ($f_o4m) {
	if ($z) echo ', ';
	if ($f_o4m==2) echo 'Только для ЧК - <b>Да</b>';
	if ($f_o4m==1) echo 'Только для ЧК - <b>Нет</b>';
	$z=1;
}

if (!$z) echo 'все';
?>.</font>
<br>
<br />
<!-- Files list -->
<!-- <font color=808080>Отсортировано по <b>дате добавления</b></font> -->
<table cellpadding=0 cellspacing=0 border=0 width="100%"><tr><td bgcolor=808080 valign=top>
<table cellpadding=4 cellspacing=1 border=0 width="100%">
         <tr bgcolor=FFFDF2 valign=top>
<!--         <tr bgcolor=e6e6e6 valign=top> -->
<td align=center><b>
<?php
if ($by<>1)
{echo '<a href="./?by=1';
include('./prodlistgetvar.i.php');
echo '" title="Сортировать по id">id</a>';}
else {echo 'id';};
?>
</b>
<hr>
<b><font size="-2">
<?php
if ($by<>9)
{echo '<a href="./?by=9';
include('./prodlistgetvar.i.php');
echo '" title="Сортировать по code">code</a>';}
else {echo 'code';};
?>
</b></font>
<hr />
Titles
</td>


<td><b>
<?php
if ($by<>3)
{echo '<a href="./?by=3';
include('./prodlistgetvar.i.php');
echo '" title="Сортировать по Названию краткому">Название краткое</a>';}
else {echo 'Название краткое';};
?>
</b></td>

<td><b>
<?php
if ($by<>4)
{echo '<a href="./?by=4';
include('./prodlistgetvar.i.php');
echo '" title="Сортировать по Группа товаров">Группа товаров</a>';}
else {echo 'Группа товаров';};
?>
</b></td>

<!--<td align=center title="Цена розничная" ><b>Розн.,<?php //echo $currsitevaluta;?></b></td> -->

<td align=center title="Количество" ><b>К-во</b></td>

<td align=center title="Характеристики" width="5%"><b>Х-ки</b></td>
<td align=center title="Цены" width="5%"><b>Цены</b></td>
<td align=center title="Изображения" width="5%"><b>Изобр.</b></td>

<td align=center title="Приоритет" width="3%"><b>
<?php
if ($by<>2)
{echo '<a href="./?by=2';
include('./prodlistgetvar.i.php');
echo '" title="Сортировать по приоритету"><img src="/images/a/i-order-b.gif" width=14 height=15 alt="Приоритет" border=0></a>';}
else {echo '<img src="/images/a/i-order-a.gif" width=14 height=15 alt="Приоритет" border=0>';};
?>
</b></td>

<td align=center title="Видно на сайте" width="3%"><b>
<?php
if ($by<>5)
{echo '<a href="./?by=5';
include('./prodlistgetvar.i.php');
echo '" title="Сортировать по видимости на сайте">V</a>';}
else {echo 'V';};
?>
</b></td>

<td align=center title="Рекомендуемый" width="3%"><b>
<?php
if ($by<>6)
{echo '<a href="./?by=6';
include('./prodlistgetvar.i.php');
echo '" title="Сортировать по Рекомендуемый">R</a>';}
else {echo 'R';};
?>
</b></td>

<td align=center title="Только для Членов Клуба" width="3%"><b>
<?php
if ($by<>8)
{echo '<a href="./?by=8';
include('./prodlistgetvar.i.php');
echo '" title="Сортировать по признаку Только для Членов Клуба">ЧК</a>';}
else {echo 'ЧК';};
?>
</b></td>

<td align=center title="Удалить" width="5%"><b>X</b></td>
        </tr>

        <tr bgcolor=f3f3f3 valign=top>
<?php
if ($by==1 || $by==9) echo '<td align=center title="Отсортировано по id"><img src="/images/a/i-arr.gif" width=7 height=4 alt="" border=0></td>';
else echo '<td></td>';
if ($by==3) echo '<td align=center title="Отсортировано по Названию краткому"><img src="/images/a/i-arr.gif" width=7 height=4 alt="" border=0></td>';
else echo '<td></td>';
if ($by==4) echo '<td align=center title="Отсортировано по Группа товаров"><img src="/images/a/i-arr.gif" width=7 height=4 alt="" border=0></td>';
else echo '<td></td>';

echo '<td></td>';
echo '<td></td>';
echo '<td></td>';
echo '<td></td>';
if ($by==2) echo '<td align=center title="Отсортировано по Приоритету"><img src="/images/a/i-arr.gif" width=7 height=4 alt="" border=0></td>';
else echo '<td></td>';
if ($by==5) echo '<td align=center title="Отсортировано по Видимости на сайте"><img src="/images/a/i-arr.gif" width=7 height=4 alt="" border=0></td>';
else echo '<td></td>';
if ($by==6) echo '<td align=center title="Отсортировано по Рекомендуемый"><img src="/images/a/i-arr.gif" width=7 height=4 alt="" border=0></td>';
else echo '<td></td>';
if ($by==8) echo '<td align=center title="Отсортировано по признаку Только для Членов Клуба"><img src="/images/a/i-arr.gif" width=7 height=4 alt="" border=0></td>';
else echo '<td></td>';
?>
<td></td>

        </tr>

<?php

$rowbgcolor='FFFFFF';

//for ($j=0;$j<$nr;$j++)
foreach ($arrayProducts as $onepr) {
	$currid = $onepr['id'];
	$currCODE = $onepr['code'];
	$btv_cat_name_ru = $onepr['cat_name_ru'];
	$allTitles = implode('<br>', $btvProduct->getTitles($currid));

	echo '<tr bgcolor=#';
	echo $rowbgcolor;
	echo ' valign=top><td align=center class=graysmall >';
	echo $currid;
	echo '<span class="siteua">' . '<hr><b>UA:</b>'.$currCODE .
	'</span>';
	if ($allTitles) {
	echo '<hr /><b>Titles</b><br />';
	echo $allTitles;
	}
	echo '</td><td>';
	echo '<a href="./?p=edit&id='.$currid.'">'.$onepr['name_ru'].'</a>';
	echo '</td><td>';
	echo $btv_cat_name_ru;
	echo '</td>';
echo '<td align=center>';
echo '<span class="siteua">' . $onepr['bookcount'] . '</span>';
echo '</td>';
echo '<td align=center>';
//*
$cnt_haracters = $btvProduct->getCountHaracters($currid);

echo '<a href="dbooks.html?id='.$currid.'" title="Характеристики">';
if ($cnt_haracters>0) echo $cnt_haracters;
else echo '<font face="Wingdings" style="text-decoration: none; font-size: 17px; color=4D7BD7; ">&#240;</font>';
echo '</a>';

echo '</td>';

echo '<td align=center>';
//*
$cnt_values = $btvProduct->getCountPriceValues($currid);

echo '<span class="siteua"><a href="prices.html?id='.$currid.'" title="Цены">';
if ($cnt_values>0) echo $cnt_values . '</span>';
echo '</a>';
//*/
echo '</td>';

echo '<td align=center>';
$cnt_images = $btvProduct->getCountImages($currid);
						
                        echo '<a href="prices.html?id='.$currid.'" title="Цены">';
						if ($cnt_images>0) echo $cnt_images;
						else echo '<font face="Wingdings" style="text-decoration: none; font-size: 17px; color=4D7BD7; ">&#240;</font>';
                        echo '</a>';
             	  
echo '</td>';

echo '<td align="center"><span class="siteua"><b>UA</b> :
<input type="text" size="3" class="form" name="rngupfile['.$currid.']" value="'.$onepr['rng'].'"></span>';
echo '</td>
<td align=center>';
echo '<input type=hidden name=idupfile[] value="'.$currid.'">';
echo '<span class="siteua"><b>UA</b>: <input type=checkbox name=idupfilesi[] value="'.$currid.'" class=gbutton ';
if ($onepr['si']) echo ' checked';
echo '></span>
</td>';

echo '<td align=center>';
echo '<input type=checkbox name=idupfilercmd[] value="'.$currid.'" class=button ';
if ($onepr['sircmd']) echo ' checked';
echo '></td>';

echo '<td align=center>';
echo '<input type=checkbox name=idupfileo4m[] value="'.$currid.'" class=button ';
if ($onepr['o4m']) echo ' checked';
echo '></td>';

echo '<td align="center"><input type=checkbox name=idupfilerm[] value="'.$currid.'" class=rbutton ';

echo '></td></tr>';

if ($rowbgcolor=='FFFFFF') {$rowbgcolor='F3F3F3';} else {$rowbgcolor='FFFFFF';};
};

?>



        <tr bgcolor=FFFFFF valign=top>
<td colspan="7" align=right><input type="Reset" class=button value="Сброс" title="Восстановить исходные значения"></td>

<td align=center colspan="4">
	<?php //if($permision==2): ?>
		<input type=button OnClick="svTh()" class=gbutton value="   OK   " title="Сохранить изменения">
	<?php //endif; ?>	
</td>

<td align=center>
	<?php //if($permision==2): ?>
		<input type=button OnClick="rmTh()" class=rbutton value=" X " title="Удалить отмеченных">
	<?php //endif; ?>		
</td>
        </tr>

</table>
</td></tr></table>
<br><br>
<!-- /Files list -->

</form>

<?php
$linkUrl = './?' . ($arrayGet ? implode('&', $arrayGet) : '');
$nr_res = $btvProduct->getList(0, 0, $paramFilter, '', true);
Pagenav($i, $p, $nr_res, $linkUrl);
function Pagenav ($i, $p, $count, $linkUrl ) {
    echo '<div align="center">';
    echo '<p align="left"><strong>Всего найдено:&nbsp;'.$count.'&nbsp; </strong> </p>';
    //echo '<hr>';
    if($count > $p){
        echo '<p align="center">Страницы:&nbsp;&nbsp;<font class="pgnv">';
        if ($i > 0){echo'<a href="'.$linkUrl.'i='.($i-1).'"><b><~</b></a>&nbsp;&nbsp;';}
        $j=0;
        while (($j*$p) < $count) {
            if ($j != $i){echo' <a href="'.$linkUrl.'i='.$j.'"><b> '.($j+1).' </b></a> ';}
            else {echo' <b> '.($j+1).' </b> ';}
            $j++;
            if(($j*$p) < $count) echo"|";
        }
    $j--;
    if ($i < $j){echo'&nbsp;&nbsp;<a href="'.$linkUrl.'i='.($i+1).'"><b>~></b></a>';}
    echo '</font>';
    echo '</p>';
    echo '<hr>';
    }
    echo '</div>'; 
}

?>



</td>
<!--Central col end-->

        </tr>
</table>
<!--Main table end-->

<?php include("../../_butt.html");?>
<!--<script
  src="https://code.jquery.com/jquery-3.1.1.min.js"
  integrity="sha256-hVVnYaiADRTO2PzUGmuLJr8BLUSjGIZsDYGmIJLv2b8="
  crossorigin="anonymous"></script>
<script>
    $( document ).ready(function() {
        $('button.reSph').on('click', function() {
            confirm('Переиндексировать Поиск ???');
            $.ajax({
             url: 'search/search_sph.php',
             type: 'POST',
             beforeSend: function(){
			$('.sph-node').hide();
                        $('.reSph').append('<img src="/img/spinner.gif" class="sph-spiner" >');
		},
             complete: function() {
                       $('.sph-spiner').hide();
                       $('.sph-node').show();
                },
             success: function (result) {
              if(result.indexOf('successfully')) alert('Успешная реиндексация');
              else alert('Что - то не так !!!!');
                }
            });
        });
    });
</script>-->
</body>
</html>