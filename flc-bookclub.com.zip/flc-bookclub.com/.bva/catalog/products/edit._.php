<?php
/*
ini_set('display_errors',1);
error_reporting(E_ALL);
*/
$title_page = 'Редактирование товара Bottega';
include($admAbspth . 'layout/header.php'); 

if (isset($_GET['id']) && is_numeric($_GET['id'])) {
	$id = $_GET['id'];
} else {
	die('Не введено ID товара');
}
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	if (isset($_POST['delete'])) {
		$btvProduct->delProduct(array(0=>$id));
		header('Location: ./');
	}
	if (isset($_POST['save'])) {
		$paramArray = array();
		$paramArray['category_id'] = $_POST['category_id'];
		$paramArray['code'] = $_POST['code'];
		$paramArray['shortname_ru'] = $_POST['shortname_ru'];
		$paramArray['shortname_ua'] = $_POST['shortname_ua'];
		$paramArray['alias'] = $_POST['alias'];
		$paramArray['name_ru'] = $_POST['name_ru'];
		$paramArray['name_ua'] = $_POST['name_ua'];
		$paramArray['brief_ru'] = $_POST['brief_ru'];
		$paramArray['brief_ua'] = $_POST['brief_ua'];
		$paramArray['rng'] = $_POST['rng'];
		$paramArray['description_ru'] = $_POST['description_ru'];
		$paramArray['description_ua'] = $_POST['description_ua'];
		$paramArray['sircmd'] = isset($_POST['sircmd']) ? 1 : 0;
		$paramArray['si'] = isset($_POST['si']) ? 1 : 0;
		$btvProduct->changeProduct($paramArray, $id);
		$btvProduct->setTitles($id, $paramArray['code'], $_POST['title']);
	}
}
$dataArrayProduct = $btvProduct->getList(0, 1, array('pr.id' => $id), '');
$dataProduct = $dataArrayProduct[0];
//print_r($dataProduct);
$d1 = explode(' ', $dataProduct['create_date']);
$d = explode('-', $d1[0]);
$create_data = $d[2] . '.' . $d[1] . '.' . $d[0] . ' ' . $d1[1];
$d1 = explode(' ', $dataProduct['update_date']);
$d = explode('-', $d1[0]);
$update_data = $d[2] . '.' . $d[1] . '.' . $d[0] . ' ' . $d1[1];

?>
<script type="text/javascript">
<!--
$(function() {
	$('input[name="save"]').click(function() {
		var err = '';
		if (!$("#mainform input[name=shortname_ru]").val()) {
			err += ' \n - короткое наименование категории(рус.)';
		}
		if (!$("#mainform input[name=shortname_ua]").val()) {
			err += ' \n - короткое наименование категории(укр.)';
		}
		if (!$("#mainform input[name=name_ru]").val()) {
			err += ' \n - длинное наименование категории(рус.)';
		}
		if (!$("#mainform input[name=name_ua]").val()) {
			err += ' \n - длиное наименование категории(укр.)';
		}
		if (!$("#mainform input[name=alias]").val()) {
			err += ' \n - alias для категории';
		}	
		/*if (!$("#mainform select[name=category_id").val()) {
			err += ' \n - выберите категорию для товара';
		}*/
		if (err) {
			alert('Введите ' + err);
			return false;
		}
	});
	$('input[name="delete"]').click(function() {
		if (!confirm('Вы действительно хотите удалить товар?')) {
			return false;
		}
	});
	$('input[name="rng"]').keyup(function(e) {
		if (e.keyCode != 0x9) {
			var val = $(this).val().replace(/[^0-9]/g, '');
			$(this).val(val);
		}
	});
})

// -->
</script>
<!--Header begin-->
<?php include($admAbspth . 'layout/top.php'); ?>
<form action="./?p=edit&id=<?php echo $id; ?>" id="mainform" method="post" enctype="multipart/form-data">

<?php include($admAbspth . 'layout/buttons.php'); ?>

<!-- H1 -->
<hr>
<table cellpadding=0 cellspacing=0 border=0 width="100%">
	<tr>
<td width=42 nowrap><img src="/images/a/i-script-b.gif" width=42 height=32 alt="" border=0></td>
<td width="100%"><font size="+1"><b><?php echo $dataProduct['shortname_ru']; ?></b></font></td>
<td>

</td>
	</tr>
	<tr><td height=5></td></tr>
	<tr>
<td></td>
<td class=graysmall><?php  echo 'ID:&nbsp;'.$id.' '; 
if ($dataProduct['code']) echo '<span class="siteua">&nbsp;&nbsp; Code:&nbsp;'.$dataProduct['code'] . '</span>';
$allTitles = implode('<br>', $btvProduct->getTitles($id));
if ($allTitles) {echo '&nbsp;&nbsp; Titles: ' . $allTitles;}
?></td>
<td></td>
	</tr>	
	
	</table>

<!-- /H1 -->
<br>
<table width="100%" cellpadding=4 cellspacing=0 border=0 bgcolor=d4d4d4>
	<tr><td height=6></td></tr>
	<tr>
<td width=1><br></td>
<td bgcolor=ffffff nowrap>&nbsp;&nbsp;<b>Описание</b>&nbsp;&nbsp;</td>
<td width=1><br></td>
<td bgcolor=f3f3f3 nowrap >&nbsp;&nbsp;<a href="./?p=haracter&id=<?php echo $id;?>">Характеристики&nbsp;(<?php 
echo $btvProduct->getCountHaracters($id); 
?>)</a>&nbsp;&nbsp;</td>
<td class="siteua" width=1><br></td>
<td class="siteua" bgcolor=f3f3f3 nowrap >&nbsp;&nbsp;<a href="./?p=price&id=<?php echo $id;?>">Цены&nbsp;(<?php 
echo $btvProduct->getCountPriceValues($id);
?>)</a>&nbsp;&nbsp;</td>
<td class="siteru" width=1><br></td>
<td width=1><br></td>
<td bgcolor=f3f3f3 nowrap >&nbsp;&nbsp;<a href="./?p=image&id=<?php echo $id;?>">Изображения&nbsp;(<?php 

echo $btvProduct->getCountImages($id); ?>)</td>


<td width=1><br></td>
<td width="100%" bgcolor=f3f3f3 nowrap align=right >
&nbsp;&nbsp;<a href="./comments/?f_pr=<?php echo $id;?>">Коммент.&nbsp;(<?php 

$r_pphotos=q_e("select ID from OOPCOMMENTS where OOPID=$id");
$nr_pphotos=q_nr($r_pphotos);

echo $nr_pphotos;?>)</a><?php 

$r_pphotos=q_e("select AVMARK from OOP2AVMARK where OOPID=$id");
$nr_pphotos=q_nr($r_pphotos);

if ($nr_pphotos>0) echo ',&nbsp;ср.&nbsp;оценка:&nbsp;'.q_r($r_pphotos,0,"AVMARK").'';

?> &nbsp;<a href="./comments/msgadd.html?pr=<?php echo $id;?>">+</a>&nbsp;&nbsp;</td>
	</tr>
</table>
<!-- News brief -->
<table cellPadding=0 cellSpacing=0 border=0 width="100%">
	<tr>
		<td align="left">&nbsp;</td>
	</tr>
	<tr>
		<td bgcolor="#808080">
			<table width="100%" cellpadding=4 cellspacing=1 border=0>
				<tr bgcolor="#FFFFFF">
					<td width="30%">ID:</td>
					<td width="70%" bgcolor=f3f3f3><?php echo $dataProduct['id']; ?></td>
				</tr>			
				<tr bgcolor="#FFFFFF">
					<td width="30%">Название короткое(рус.):</td>
					<td width="70%" bgcolor=f3f3f3><input type="text" name="shortname_ru"
						value="<?php echo $dataProduct['shortname_ru']; ?>" size="59" /></td>
				</tr>
				<tr bgcolor="#FFFFFF">
					<td width="30%">Название короткое(укр.):</td>
					<td width="70%" bgcolor=f3f3f3><input type="text" name="shortname_ua"
						value="<?php echo $dataProduct['shortname_ua']; ?>" size="59" /></td>
				</tr>
				<tr bgcolor="#FFFFFF">
					<td width="30%">Название длинное(рус.):</td>
					<td width="70%" bgcolor=f3f3f3><input type="text" name="name_ru"
						value="<?php echo $dataProduct['name_ru']; ?>" size="59" /></td>
				</tr>
				<tr bgcolor="#FFFFFF">
					<td width="30%">Название длинное(укр.):</td>
					<td width="70%" bgcolor=f3f3f3><input type="text" name="name_ua"
						value="<?php echo $dataProduct['name_ua']; ?>" size="59" /></td>
				</tr>
				<tr bgcolor="#FFFFFF">
					<td width="30%">Alias:</td>
					<td width="70%" bgcolor=f3f3f3><input type="text<?php //echo $btvCat->parent_id ? 'text' : 'hidden'; ?>" name="alias"
						value="<?php echo $dataProduct['alias']; ?>" size="59" /></td>
				</tr>
				<tr bgcolor="#FFFFFF">
					<td width="30%">Code:</td>
					<td width="70%" bgcolor=f3f3f3><input type="text" name="code"
						value="<?php echo $dataProduct['code']; ?>" size="59" /></td>
				</tr>
				<tr bgcolor="#FFFFFF">
					<td width="30%">Title (через запятую):</td>
					<td width="70%" bgcolor=f3f3f3><input type="text" name="title"
						value="<?php 
							if ($allTitles) {
								echo $allTitles;
							}?>" size="59" /></td>
				</tr>
				<tr bgcolor="#FFFFFF">
					<td width="30%">Открыт:</td>
					<td width="70%" bgcolor=f3f3f3>
					<input type="checkbox" name="si" value="1" <?php echo $dataProduct['si'] ? " checked='checked'" : ''; ?> /></td>
				</tr>
				<tr bgcolor="#FFFFFF">
					<td width="30%">Ранг:</td>
					<td width="70%" bgcolor=f3f3f3><input type="text" name="rng"
						value="<?php echo $dataProduct['rng']; ?>" size="2" /></td>
				</tr>
				<tr bgcolor="#FFFFFF">
					<td width="30%">Рекомендуемый товар:</td>
					<td width="70%" bgcolor=f3f3f3>
						<input type="checkbox" name="sircmd" value="1" <?php echo $dataProduct['sircmd'] ? " checked='checked'" : ''; ?> />
						(Показывать в списках товаров)</td>
				</tr>				
                <tr bgcolor="#FFFFFF">
					<td width="30%">Родительская категория:</td>
					<td width="70%" bgcolor=f3f3f3>
					<?php if ($dataProduct['category_id']) : ?>
						<select name="category_id" style="width: 380px">
							<?php foreach ($listCategories as $cat) : ?>
								<option value='<?php echo $cat['id']; ?>'
									<?php if ($dataProduct['category_id'] == $cat['id']) : ?>
										selected="selected"
									<?php endif; ?>
								><?php
									for($p = 0; $p < $cat['level']; $p ++) {
										echo '&mdash;';
									}
									echo $cat['name_ru']; ?>
								</option>
							<?php endforeach; ?>
						</select>
					<?php else : ?>
						ВЕРХНИЙ УРОВЕНЬ
					<?php endif; ?>
				</tr>
				<tr bgcolor="#FFFFFF">
					<td width="30%">Краткое описание(рус.):</td>
					<td width="70%" bgcolor=f3f3f3>
						<textarea name="brief_ru" style="width: 380px" ><?php echo $dataProduct['brief_ru']; ?></textarea>
					</td>
				</tr>
				<tr bgcolor="#FFFFFF">
					<td width="30%">Краткое описание(укр.):</td>
					<td width="70%" bgcolor=f3f3f3>
						<textarea name="brief_ua" style="width: 380px" ><?php echo $dataProduct['brief_ua']; ?></textarea>
					</td>
				</tr>				
				<tr bgcolor="#FFFFFF">
					<td width="30%">Описание(рус.):</td>
					<td width="70%" bgcolor=f3f3f3>
						<textarea name="description_ru" style="width: 380px" ><?php echo $dataProduct['description_ru']; ?></textarea>
					</td>
				</tr>
				<tr bgcolor="#FFFFFF">
					<td width="30%">Описание(укр.):</td>
					<td width="70%" bgcolor=f3f3f3>
						<textarea name="description_ua" style="width: 380px" ><?php echo $dataProduct['description_ua']; ?></textarea>
					</td>
				</tr>				
				<tr bgcolor="#FFFFFF">
					<td width="30%"> Дата создания:</td>
					<td width="70%" bgcolor=f3f3f3><?php echo $create_data; ?></td>
				</tr>
				<tr bgcolor="#FFFFFF">
					<td width="30%"> Дата обновления:</td>
					<td width="70%" bgcolor=f3f3f3><?php echo $update_data; ?></td>
				</tr>
			</table>
		</td>
	</tr>
</table>
<div style="width: 100%; clear:both"><br /></div>

<?php 
//if (!$btvCat->checkCatOnParent($id)) {
	//$but_delete = 'Удалить товар';
//}
include($admAbspth . 'layout/buttons.php'); ?>

</form>
<?php include($admAbspth . 'layout/bottom.php'); ?>