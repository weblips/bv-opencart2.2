<?php

$title_page = 'Редактирование категории';
include($admAbspth . 'layout/header.php');
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
	$id = $_GET['id'];
} else {
	die('Не введено ID категории');
}
if (isset($_POST['delete'])) {
	$btvCat->delCategory(array(0=>$id));
	header('Location: ./');
}
if (isset($_POST['save'])) {
	$btvCat->name_ru = $_POST['name_ru'];
	$btvCat->name_ua = $_POST['name_ua'];
	$btvCat->alias = $_POST['alias'];
	$btvCat->rng = $_POST['rng'];
	$btvCat->parent_id = $_POST['parent_id'];
	$btvCat->description_ru = $_POST['description_ru'];
	$btvCat->description_ua = $_POST['description_ua'];
	$btvCat->si = isset($_POST['si']) ? 1 : 0;
	if ($btvCat->parent_id) {
		$btvCat->level = $btvCat->getLevelFromId($btvCat->parent_id) + 1;
	}
	$btvCat->changeCategory($id);
}
$btvCat->getCategory($id);

$d1 = explode(' ', $btvCat->create_data);
$d = explode('-', $d1[0]);
$create_data = $d[2] . '.' . $d[1] . '.' . $d[0] . ' ' . $d1[1];
$d1 = explode(' ', $btvCat->update_data);
$d = explode('-', $d1[0]);
$update_data = $d[2] . '.' . $d[1] . '.' . $d[0] . ' ' . $d1[1];

$listCategories = $btvCat->getAllCategories(0);
?>
<script type="text/javascript">
<!--
$(function() {
	$('input[name="save"]').click(function() {
		var err = '';
		if (!$("#mainform input[name=name_ru]").val()) {
			err += ' \n - наименование категории(рус.)';
		}
		if (!$("#mainform input[name=name_ua]").val()) {
			err += ' \n - наименование категории(укр.)';
		}
<?php if ($btvCat->parent_id) : ?>
		if (!$("#mainform input[name=alias]").val()) {
			err += ' \n - alias для категории';
		}
<?php endif; ?>		
		if (err) {
			alert('Введите ' + err);
			return false;
		}
	});
	$('input[name="delete"]').click(function() {
		if (!confirm('Вы действительно хотите удалить категорию?')) {
			return false;
		}
	});
	$('input[name="rng"]').keyup(function(e) {
		if (e.keyCode != 0x9) {
			var val = $(this).val().replace(/[^0-9]/g, '');
			$(this).val(val);
		}
	});
})

// -->
</script>
<!--Header begin-->
<?php include($admAbspth . 'layout/top.php'); ?>

<form action="./?p=edit&id=<?php echo $id; ?>" id="mainform" method="post">

<?php include($admAbspth . 'layout/buttons.php'); ?>

<!-- News brief -->
<table cellPadding=0 cellSpacing=0 border=0 width="100%">
	<tr>
		<th align="left">Редактирование категории</th>
	</tr>
	<tr>
		<td bgcolor="#808080">
			<table width="100%" cellpadding=4 cellspacing=1 border=0>
				<tr bgcolor="#FFFFFF">
					<td width="30%">ID:</td>
					<td width="70%" bgcolor=f3f3f3><?php echo $id; ?></td>
				</tr>			
				<tr bgcolor="#FFFFFF">
					<td width="30%">Название(рус.):</td>
					<td width="70%" bgcolor=f3f3f3><input type="text" name="name_ru"
						value="<?php echo $btvCat->name_ru; ?>" size="59" /></td>
				</tr>
				<tr bgcolor="#FFFFFF">
					<td width="30%">Название(укр.):</td>
					<td width="70%" bgcolor=f3f3f3><input type="text" name="name_ua"
						value="<?php echo $btvCat->name_ua; ?>" size="59" /></td>
				</tr>
				<tr bgcolor="#FFFFFF">
					<td width="30%">Alias:</td>
					<td width="70%" bgcolor=f3f3f3><input type="<?php echo $btvCat->parent_id ? 'text' : 'hidden'; ?>" name="alias"
						value="<?php echo $btvCat->alias; ?>" size="59" /></td>
				</tr>
				<tr bgcolor="#FFFFFF">
					<td width="30%">Открыта:</td>
					<td width="70%" bgcolor=f3f3f3>
					<input type="checkbox" name="si" value="1" <?php echo $btvCat->si ? " checked='checked'" : ''; ?> /></td>
				</tr>
				<tr bgcolor="#FFFFFF">
					<td width="30%">Ранг:</td>
					<td width="70%" bgcolor=f3f3f3><input type="text" name="rng"
						value="<?php echo $btvCat->rng; ?>" size="2" /></td>
				</tr>			
                <tr bgcolor="#FFFFFF">
					<td width="30%">Родительская категория:</td>
					<td width="70%" bgcolor=f3f3f3>
					<?php if ($btvCat->parent_id) : ?>
						<select name="parent_id" style="width: 380px">
							<?php foreach ($listCategories as $cat) : 
								if ($id == $cat['id']) {
									continue;
								}			
							?>
								<option value='<?php echo $cat['id']; ?>'
									<?php if ($btvCat->parent_id == $cat['id']) : ?>
										selected="selected"
									<?php endif; ?>
								><?php
									for($p = 0; $p < $cat['level']; $p ++) {
										echo '&mdash;';
									}
									echo $cat['name_ru']; ?>
								</option>
							<?php endforeach; ?>
						</select>
					<?php else : ?>
						ВЕРХНИЙ УРОВЕНЬ
					<?php endif; ?>
				</tr>
				
				<tr bgcolor="#FFFFFF">
					<td width="30%">Описание(рус.):</td>
					<td width="70%" bgcolor=f3f3f3>
						<textarea name="description_ru" style="width: 380px" ><?php echo $btvCat->description_ru; ?></textarea>
					</td>
				</tr>
				<tr bgcolor="#FFFFFF">
					<td width="30%">Описание(укр.):</td>
					<td width="70%" bgcolor=f3f3f3>
						<textarea name="description_ua" style="width: 380px" ><?php echo $btvCat->description_ua; ?></textarea>
					</td>
				</tr>				
				<tr bgcolor="#FFFFFF">
					<td width="30%"> Дата создания:</td>
					<td width="70%" bgcolor=f3f3f3><?php echo $create_data; ?></td>
				</tr>
				<tr bgcolor="#FFFFFF">
					<td width="30%"> Дата обновления:</td>
					<td width="70%" bgcolor=f3f3f3><?php echo $update_data; ?></td>
				</tr>
			</table>
		</td>
	</tr>
</table>
<div style="width: 100%; clear:both"><br /></div>

<?php 
if (!$btvCat->checkCatOnParent($id)) {
	$but_delete = 'Удалить категорию';
}
include($admAbspth . 'layout/buttons.php'); ?>

</form>
<?php include($admAbspth . 'layout/bottom.php'); ?>