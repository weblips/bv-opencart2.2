<?php

/*$sql = "SELECT * FROM btv_categories WHERE parent_id = 1 ORDER BY rng";
$res = q_e($sql);

echo 'res=' . q_r($res, 0, 'name_ru');*/

/*ini_set('display_errors',1);
error_reporting(E_ALL);*/
	$title_page = 'Структура категорий Bottega';
	include($admAbspth . 'layout/header.php'); 

	/*if ($_GET['i']) {
		$i = $_GET['i'];
	} else {
		$i = 0;
	}	
	$p = 30;*/
	if (isset($_POST['delete'])) {
		$btvCat->delCategory($_POST['id_delcat']);
		header('Location: ./');
	}
	if (isset($_POST['gsi']) && !empty($_POST['gsi'])) {
		$mhsi = $mrng = array();
		
		if (isset($_POST['hsi']) && !empty($_POST['hsi'])) {
			$msi = isset($_POST['si']) ? $_POST['si'] : array();
			$mhsi = $_POST['hsi'];
			foreach ($msi as $v) {
				$mhsi[$v] = 1;
			}
		}
		if (isset($_POST['rng']) && !empty($_POST['rng'])) {
			$mrng = isset($_POST['rng']) ? $_POST['rng'] : array();
		}
		if ($mhsi || $mrng) {
			$btvCat->setCategoriesSiRng($mhsi, $mrng);
		}
	}
	$listCategories = $btvCat->getAllCategories(0);
	/*echo '<pre>';	
	print_r($listCategories);
	echo '</pre>';
	exit;*/
?>

<script type="text/javascript">
<!--
$(function() {
	$('input[name="delete"]').click(function() {
		if ($("input[name='id_delcat[]']:checked").length == 0 || !confirm('Вы действительно хотите удалить выбранные категории?')) {
			return false;
		}
	});
})
// -->
</script>

<?php include($admAbspth . 'layout/top.php');  ?>


	<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" name="listform">
<?php 
$dop_ref = '<td align="right"><img src="/images/a/i-txt-add.gif" width="17" height="16" alt="Создать ценовое правило" border="0" align="absmiddle" hspace="4"><a href="./?p=add">Создать категорию</a></td>';
$nosave = 1;
include($admAbspth . 'layout/buttons.php'); ?>

	<!-- <font color="#808080">Показаны правила: 
	</font><br><br>
	/News list -->
	<table cellpadding="0" cellspacing="0" border="0" width="100%">
	<tr>
		<th align="left">Структура категорий <?php //echo VIEWSITE; ?></th>
	</tr>
	<!--<tr valign="top" bgcolor="f3f3f3">
            <td width="600" style="padding-top:10px">Поиск по ID товара: <input type="text" value="<?php echo $gid ? $gid : ''; ?>" class="form" size="7" name="gid" />&nbsp;
			По наименованию товара: <input type="text" value="<?php echo $name_gid ? $name_gid : ''; ?>" class="form" size="30" name="name_gid">
            <input type="submit" value="Искать" class="form"></td>
	</tr>-->
		<tr><td>&nbsp;</td></tr>
		<tr>
			<td bgcolor="#808080">
				<table cellpadding="4" cellspacing="1" border="0" width="100%">
					<tr bgcolor="#FFFFFF" style="font-size: 12px">
						<th width="5%">ID</th>
						<th width="25%">Наименование(рус.)</th>
						<th width="25%">Наименование(укр.)</th>
						<th width="20%">Alias</th>
						<th width="10%">Ранг</th>
						<th width="5%">V</th>
						<th title="Отиетить для удаления" style="color: red"> X </th>
					</tr>
					<?php if (!empty($listCategories)) :
						foreach($listCategories as $cat) : ?>
							<tr bgcolor="#FFFFFF">
								<td><?php echo $cat['id']; ?></td>
								<td><?php
								for($p = 0; $p < $cat['level']; $p ++) {
									echo '<img src="/images/a/1.gif" width="22" height="15">';
								} 
								?>
									<img src="/images/a/i-script.gif" width="17" height="16" border="0" hspace="1">
									<a href="./?p=edit&id=<?php echo $cat['id']; ?>"><?php echo $cat['name_ru']; ?></a></td>
								<td><a href="./?p=edit&id=<?php echo $cat['id']; ?>"><?php echo $cat['name_ua']; ?></a></td>
								<td><a href="./?p=edit&id=<?php echo $cat['alias']; ?>"><?php echo $cat['alias']; ?></a></td>
								<td>
								<?php for($p = 0; $p < $cat['level']; $p ++) {
									echo '|';
								} ?>
								<input type="text" name="rng[<?php echo $cat['id']; ?>]" value="<?php echo $cat['rng']; ?>" size="2" /></td>
								<td align="center">
									<input type="hidden" name="hsi[<?php echo $cat['id']; ?>]" value="0" />
									<input type="checkbox" name="si[]" value="<?php echo $cat['id']; ?>" 
									<?php echo $cat['si'] ? ' checked="checked"' : ''; ?> />
								</td>
								<td align="center">
									<input title="Отметить для удаления"
									 <?php echo $btvCat->checkCatOnParent($cat['id']) || $btvCat->checkProductInCategory($cat['id']) ? ' disabled' : ''; ?> 
									type="checkbox" name="id_delcat[]" value="<?php echo $cat['id']; ?>" />
								</td>
							</tr>
						<?php endforeach;
					endif; ?>
					<tr bgcolor="#FFFFFF">
						<td colspan="4"></td>
						<td colspan="2" align="center">
							<input name='gsi' type="submit" title="Сохранить изменения" value=" OK " class="gbutton" />
						</td>						
						<td align="center">
							<input name='delete' type="submit" title="Удалить отмеченные" value=" X " class="rbutton" />
						</td>
					</tr>
				</table>
			</td>
		</tr>
	</table>
	
	
	</form>


<?php
/*
$link = $PHP_SELF . '?' . ($name_gid ? "name_gid=$name_gid&" : '');
if (isset($_GET['type']) && !empty($_GET['type'])) {
	$link .= 'type=' . $_GET['type'] . '&';
}
$nr_res = $rp->getListPriceRule($f_type, '', '', $gid, $name_gid);
$nr_res = $nr_res[0]['c'];

Pagenav($i, $p, $nr_res, $link);
function Pagenav ($i, $p, $count, $link ) {
    echo '<div align="center">';
    echo '<p align="left"><strong>Всего найдено:&nbsp;'.$count.'&nbsp; </strong> </p>';
    //echo '<hr>';
    if($count > $p){
        echo '<p align="center">Страницы:&nbsp;&nbsp;<font class="pgnv">';
        if ($i > 0){echo'<a href="'.$link.'i='.($i-1).'"><b><~</b></a>&nbsp;&nbsp;';}
        $j=0;
        while (($j*$p) < $count) {
            if ($j != $i){echo' <a href="'.$link.'i='.$j.'"><b> '.($j+1).' </b></a> ';}
            else {echo' <b> '.($j+1).' </b> ';}
            $j++;
            if(($j*$p) < $count) echo"|";
        }
    $j--;
    if ($i < $j){echo'&nbsp;&nbsp;<a href="'.$link.'i='.($i+1).'"><b>~></b></a>';}
    echo '</font>';
    echo '</p>';
    echo '<hr>';
    }
    echo '</div>'; 
}
//*/
?>
</td>
<!--Central col end-->

	</tr>
</table>
<div style="width: 100%; clear:both"><br /></div>

<?php include($admAbspth . 'layout/bottom.php'); ?>
