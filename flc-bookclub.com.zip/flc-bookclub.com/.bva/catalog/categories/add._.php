<?php
$title_page = 'Создание новой категории';
if (isset($_POST['save'])) {
	$btvCat->name_ru = $_POST['name_ru'];
	$btvCat->name_ua = $_POST['name_ua'];
	$btvCat->alias = $_POST['alias'];
	$btvCat->rng = $_POST['rng'];
	$btvCat->parent_id = $_POST['parent_id'];
	$btvCat->description_ru = $_POST['description_ru'];
	$btvCat->description_ua = $_POST['description_ua'];
	$btvCat->si = isset($_POST['si']) ? 1 : 0;
	$btvCat->level = $btvCat->getLevelFromId($btvCat->parent_id) + 1;
	$new_id = $btvCat->changeCategory();
	header('Location: ./?p=edit&id='.$new_id);
}
$listCategories = $btvCat->getAllCategories(0);
include($admAbspth . 'layout/header.php');
?>
<script language="JavaScript" type="text/javascript">
<!--
$(function() {
	/*$.datepicker.setDefaults(
		$.extend($.datepicker.regional["ru"])
	);
	$(".datepicker").datepicker();
	*/
	$("#mainform").submit(function() {
		var err = '';
		if (!$("#mainform input[name=name_ru]").val()) {
			err += ' \n - наименование категории(рус.)';
		}
		if (!$("#mainform input[name=name_ua]").val()) {
			err += ' \n - наименование категории(укр.)';
		}
		if (!$("#mainform input[name=alias]").val()) {
			err += ' \n - alias для категории';
		}	
		if (!$("#mainform select[name=parent_id]").val()) {
			err += ' \n - выберите родительскую категорию';
		}			
		if (err) {
			alert('Введите ' + err);
			return false;
		}
	});
	$('input[name="rng"]').keyup(function(e) {
		if (e.keyCode != 0x9) {
			var val = $(this).val().replace(/[^0-9]/g, '');
			$(this).val(val);
		}
	});
})
// -->
</script>
<!--Header begin-->
<?php include($admAbspth . 'layout/top.php'); ?>

<form action="./?p=add" id="mainform" method="post">

<?php include($admAbspth . 'layout/buttons.php'); ?>

<!-- News brief -->
<table cellPadding=0 cellSpacing=0 border=0 width="100%">
	<tr>
		<th align="left">Создание новой категории</th>
	</tr>
	<tr>
		<td bgcolor="#808080">
			<table width="100%" cellpadding=4 cellspacing=1 border=0>		
				<tr bgcolor="#FFFFFF">
					<td width="30%">Название(рус.):</td>
					<td width="70%" bgcolor=f3f3f3><input type="text" name="name_ru"
						value="" size="59" /></td>
				</tr>
				<tr bgcolor="#FFFFFF">
					<td width="30%">Название(укр.):</td>
					<td width="70%" bgcolor=f3f3f3><input type="text" name="name_ua"
						value="" size="59" /></td>
				</tr>
				<tr bgcolor="#FFFFFF">
					<td width="30%">Alias:</td>
					<td width="70%" bgcolor=f3f3f3><input type="text" name="alias"
						value="" size="59" /></td>
				</tr>
				<tr bgcolor="#FFFFFF">
					<td width="30%">Открыта:</td>
					<td width="70%" bgcolor=f3f3f3>
					<input type="checkbox" name="si" value="1" /></td>
				</tr>
				<tr bgcolor="#FFFFFF">
					<td width="30%">Ранг:</td>
					<td width="70%" bgcolor=f3f3f3><input type="text" name="rng"
						value="" size="2" /></td>
				</tr>			
                <tr bgcolor="#FFFFFF">
					<td width="30%">Родительская категория:</td>
					<td width="70%" bgcolor=f3f3f3>
					<select name="parent_id" style="width: 380px">
						<option value=""></option>
						<?php foreach ($listCategories as $cat) : ?>
							<option value='<?php echo $cat['id']; ?>'
							><?php
								for($p = 0; $p < $cat['level']; $p ++) {
									echo '&mdash;';
								}
								echo $cat['name_ru']; ?>
							</option>
						<?php endforeach; ?>
					</select>
				</tr>
				
				<tr bgcolor="#FFFFFF">
					<td width="30%">Описание(рус.):</td>
					<td width="70%" bgcolor=f3f3f3>
						<textarea name="description_ru" style="width: 380px" ></textarea>
					</td>
				</tr>
				<tr bgcolor="#FFFFFF">
					<td width="30%">Описание(укр.):</td>
					<td width="70%" bgcolor=f3f3f3>
						<textarea name="description_ua" style="width: 380px" ></textarea>
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table>
<br />
<div style="width: 100%; clear:both"><br /></div>

<?php include($admAbspth . 'layout/buttons.php'); ?>

</form>
<?php include($admAbspth . 'layout/bottom.php');

