<?php
/*
function checkBusy($e) {
	i$fp = fopen(dirname(__FILE__) . '/../../myfolder/busy/log-'.date('Y-m-d').'.txt', 'a');
	$info = '';
	$load_average = load_average();
	if($load_average) {
		$load_average = $load_average['average'];
	}
	$info .= date('d-m-Y H:i:s') . "\t" . $e . "\t" . $load_average . "\t" . $_SERVER['REQUEST_URI'] . "\t" . $_SERVER['REMOTE_ADDR'];
	fwrite($fp, $info . "\n");
	fclose($fp);
	f (defined('SITEROOT')) {
		$filecontent = trim(file_get_contents(SITEROOT . 'myfolder/busy/find/query.txt'));
		if ($filecontent != 'empty') {	
			copy (SITEROOT . 'myfolder/busy/find/query.txt', SITEROOT . 'myfolder/busy/find/query-' . date('d-m-Y-H-i-s') . '.txt');
			$fp = fopen(SITEROOT . 'myfolder/busy/find/query.txt', 'w');
			fwrite($fp, 'empty');
			fclose($fp);
			mail('konstantin.golikov@bookclub.ua', 'BUSY!!!!!', $_SERVER['REQUEST_URI']);
			//mail('sergey.chekanov@bookclub.ua', 'BUSY!!!!!', $_SERVER['REQUEST_URI']);
		}
	}	
}*/
//PDO start /*
try { Registry::register("db"); } catch (PDOException $e) { 
	//checkBusy('pdo'); 
	//header('Location: /busy.html'); exit; 
}	
$DB=Registry::extract("db");
$DB->exec("SET NAMES 'utf8'");
//PDO finish */
	
$accounDb = $DB->getAccount();
/*echo '<pre>';
print_r($accounDb);
echo '</pre>';*/
$client = $accounDb['user']; 
$magicw = $accounDb['passwd'];
$dbnm = $accounDb['db'];
$thishost = $accounDb['host'];	

//old version start /*
$link=mysql_connect("$thishost","$client","$magicw"); 
//if (!$link) { checkBusy('normal'); header('Location: /busy.html'); exit; };
mysql_select_db($dbnm,$link);
mysql_query("SET NAMES 'utf8'",$link);
//old version finish */	

//Registry::register("funcs");
//include('/var/www/bookclub/data/www/bookclub.ua/.bin/com/constantreload.inc.php');