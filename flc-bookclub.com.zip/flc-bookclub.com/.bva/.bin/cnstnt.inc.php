<?php
ini_set('default_charset', 'utf-8');
//ini_set('register_globals', 'Off');
if (!isset($_SESSION)) {
	session_start();
}
$varSite = 'site17';
if (isset($_GET['site']) && ($_GET['site'] == 'ru' || $_GET['site'] == 'ua' || $_GET['site'] == 'all')) {
	$site = $_SESSION[$varSite] = $_GET['site'];
} elseif (isset($_SESSION[$varSite]) && ($_SESSION[$varSite] == 'ru' || $_SESSION[$varSite] == 'ua' || $_SESSION[$varSite] == 'all')) {
	$site = $_SESSION[$varSite];
} else {
	$site = $_SESSION[$varSite] = 'all';
}

$site = 'ua';

//define('SITEURLNOS', 'http://www.bookclub.ua');
/*	define('DIRRUSITER', '_rusite/');
	define('DIRRUSITEL', '/_rusite');	
	define('VIEWSITE', '(РОССИЯ)');
	define('RUSITEDIR', RUSITE . '/');
*/
define('RUSITE', '');
define('SITEROOT', __DIR__ . '/../');
$rusite = RUSITE;
ini_set('memory_limit','512M');

define ('IF_LOCAL_SITE', $_SERVER['HTTP_HOST'] == 'localhost' ? 1 : 0);
if(!defined('DS')) define('DS', DIRECTORY_SEPARATOR);
$isthislocal=0;
if (!isset($abspth)) $abspth= __DIR__ . '/../../';
$admAbspth = $abspth . '.bva/';
if ($isthislocal) {

} else if (IF_LOCAL_SITE) {
 
    //$abspth = $_SERVER['DOCUMENT_ROOT'] . "bookclub/";
    define('BASE_URL', 'http://' . $_SERVER['HTTP_HOST'] . '/bottega/');  
} else {
    
//if (!isset($abspth)) $abspth="/virt/homes/bookclub/htdocs/";
define('BASE_URL', 'http://' . $_SERVER['HTTP_HOST'] . '/');    
}
$imgpthg="img/products/";
//$httpimgpth='http://bookclub.ua/images/db/';
$slsh='/';
$aprtdrnm='.bva';

$dbnm='bottega';

$dwndir='../../download/';
$attachdir='../../attachment/';

$simplesplin='\_';
$dot1='_';
$dot2='.';

//$currsitevaluta='&nbsp;у.е.';
$currsitevaluta='&nbsp;грн.';
$currsitevaluta_rusite='&nbsp;руб.';
//$currsitevaluta='&nbsp;USD';
//$currsitevaluta='$';

require_once($abspth.'.bin/autoload.php');  /*функция автозагрузки классов*/
?>