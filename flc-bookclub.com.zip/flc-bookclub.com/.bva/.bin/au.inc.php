<?php

$ausr=$awrd=0;

if (isset($_POST['getusr']) && $_POST['getusr']) $getusr=clrphphtmltgs($_POST['getusr']); else $getusr='';
if (isset($_POST['getwrd']) && $_POST['getwrd']) $getwrd=clrphphtmltgs($_POST['getwrd']); else $getwrd='';

if ($getusr && $getwrd) {

  $qau="select id from admin_users where login='$getusr' and password='$getwrd'";
  $rau=q_e($qau);
  $nrau=q_nr($rau);
//echo $nrau;
//exit;
if ($nrau) {
setcookie("ausr0","$getusr",time()+36000,"/","",0);
setcookie("awrd0","$getwrd",time()+36000,"/","",0);
$ausr=$getusr;
$awrd=$getwrd;
} else {

if (isset($ausr0) && $ausr0 && isset($awrd0) && $awrd0) {
$ausr=$ausr0;
$awrd=$awrd0;
};};

  $qau="";
  $rau=0;
  $nrau=0;

} else {
	if (isset($_GET['out'])) {
		$out = $_GET['out'];
	}
	if (isset($out) && $out) {
		setcookie("ausr0","",time()+36000,"/","",0);
		setcookie("awrd0","",time()+36000,"/","",0);
	} else {
		if (isset($_COOKIE['ausr0'])) {
			$ausr0 = $_COOKIE['ausr0'];
		}
		if (isset($_COOKIE['awrd0'])) {
			$awrd0 = $_COOKIE['awrd0'];
		}
		if (isset($ausr0) && $ausr0 && isset($awrd0) && $awrd0) {
			$ausr=$ausr0;
			$awrd=$awrd0;
		}
	}
}

$ausr=clrphphtmltgs($ausr);
$awrd=clrphphtmltgs($awrd);

if (isset($getnavtree) && $getnavtree==1)
 setcookie("navtree0",1,1688210884,"/".$aprtdrnm."/",$srvname4cookie,0);
if (isset($getnavtree) && $getnavtree==2)
 setcookie("navtree0",2,1688210884,"/".$aprtdrnm."/",$srvname4cookie,0);

$navtree0=isset($_COOKIE["navtree0"]) && $_COOKIE["navtree0"] ? $_COOKIE["navtree0"] : '';


// Date in the past
header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");

// always modified
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
 
// HTTP/1.1
header("Cache-Control: no-store, no-cache, must-revalidate");
header("Cache-Control: post-check=0, pre-check=0", false);

// HTTP/1.0
header("Pragma: no-cache");


?>
