<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
    <meta HTTP-EQUIV="Pragma" CONTENT="no-cache">
    <META HTTP-EQUIV="Expires" CONTENT="Mon, 01 Jan 2001 00:00:01 GMT">
    <title><?php echo $_SERVER["SERVER_NAME"];?> -  <?php echo $title_page; ?></title>
<link rel="stylesheet" type="text/css" href="<?php echo BASE_URL; ?>.bva/style/adm.css">
<script type="text/javaScript" src="../../../../.bin/js/jquery-1.6.2.min.js"></script>
<meta http-equiv="Content-Type" content="text/html;utf-8">
</head>
<body bgcolor="#f3f3f3" ><div align="center">