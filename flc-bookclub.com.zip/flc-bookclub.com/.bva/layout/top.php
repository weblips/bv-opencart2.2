<table cellPadding="4" cellSpacing="0" border="0" width="100%" >
    <tr>
		<td bgcolor="#f3f3f3" valign="top">
		<h2>Bottega</h2>
		<a href="/.cap/.bottega">Админка Bottega</a> / <?php echo $title_page; ?></td>
    </tr>
</table>
<!--Header end-->

<table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#808080"><tr><td height="1"></td></tr></table>

<!--Main table begin-->
<table cellPadding="4" cellSpacing="1" border="0" width="100%" bgcolor="#FFFFFF">
    <tr>

<?php include("../../_menu_bottega.php");?>

<!--Central col begin-->
<td width="100%" valign="top" bgcolor="#FFFFFF">