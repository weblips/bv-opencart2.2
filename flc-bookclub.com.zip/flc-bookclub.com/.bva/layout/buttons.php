<?php if (isset($hr_button)) : ?>
	<hr>
<?php endif; ?>
<!-- Submit -->
<table cellPadding="1" cellSpacing="0" border="0" bgcolor="#808080" width="100%">
	<tr>
		<td>
			<table cellPadding="6" cellSpacing="0" border="0" bgcolor="#f3f3f3" width="100%">
				<tr>
					<?php if (!isset($nosave)) : ?>
						<td>
							<input name="save" type="submit" value="Записать в базу" class="gbutton">  
							<input type="reset" value="Сброс" class="button">
						</td>
					<?php endif; ?>
					<?php if(isset($dop_ref)) {
						echo '<td>' . $dop_ref . '</td>';
						unset($dop_ref);	
					} ?>
					<?php if (isset($but_delete)) : ?>
						<td align="right">
							<input name='delete' type="submit" value="Удалить" class="rbutton" title="<?php echo $but_delete; ?>" />
						</td>
					<?php elseif (isset($ref)) : ?>
						<td align="right">
							<?php echo $ref; ?>
						</td>
					<?php endif; ?>
				</tr>
			</table>
		</td>
	</tr>
</table>
<?php if (!isset($hr_button)) : ?>
	<hr>
<?php $hr_button = true;
	endif; ?>
<br>
<!-- /Submit -->