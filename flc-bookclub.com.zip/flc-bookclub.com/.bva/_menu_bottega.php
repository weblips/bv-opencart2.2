<?php 
$permision=whoau();
?>
<style type="text/css">
	<?php if (isset($site) && $site == 'ua') : ?>
		.siteru {
			display: none;
		}
	<?php endif; ?>
	<?php if (isset($site) && $site == 'ru') : ?>
		.siteua {
			display: none;
		}
	<?php endif; ?>
		.siteru, a.siteru, .siteru a{
			color: #16651d;
		}
</style>		
<!--Left col begin-->
<td bgcolor="#f3f3f3" valign="top" width="150">
<?php if ($isthislocal==1) $btv_aprtdrnm = 'upravlenie'; else $btv_aprtdrnm = BASE_URL . '.bva/'; ?>
<a href="<?php echo $btv_aprtdrnm; ?>catalog/categories" ><b>Категории товаров</b></a>&nbsp;&nbsp;<a href="<?php echo $btv_aprtdrnm; ?>catalog/categories/?p=add" title="Добавить категорию">+</a><br>
<table  cellspacing="0"><tr><td height="3"></td></table>
<hr>
<a href="<?php echo $btv_aprtdrnm; ?>catalog/products" style="font-size:18px; font-family:Verdana, Arial, Helvetica, sans-serif;">Товары</a>&nbsp;
<?php //if($permision==2):?><a href="<?php echo $btv_aprtdrnm; ?>catalog/products/?p=add" style="text-decoration:none; font-size:18px; font-family:Verdana, Arial, Helvetica, sans-serif;" title="Добавить товар">+</a><?php //endif;?><br>
<ul class="admin_nav">
	<?php if($permision==2):?>
		<li class="siteua"><a href="<?php echo $btv_aprtdrnm; ?>goods/import.html">Заливка кол-ва</a></li>
		<li class="siteru"><a href="<?php echo $btv_aprtdrnm; ?>goods/import_rusite.html">Заливка кол-ва (РОССИЯ)</a></li>
    <?php endif;?>
	<?php if($permision==2):?>
		<li class="siteua"><a href="<?php echo $btv_aprtdrnm; ?>goods/priority/importpriority.html">Приоритеты + позиции(файлы)</a></li>	
		<li class="siteru"><a href="<?php echo $btv_aprtdrnm; ?>goods/priority/importpriority_rusite.html">Приоритеты + позиции(файлы РОС)</a></li>
		<li class="siteua"><a href="<?php echo $btv_aprtdrnm; ?>goods/goodsBV/">Товары BV</a></li>	
		<li class="siteua"><a href="<?php echo $btv_aprtdrnm; ?>goods/allgoods.html">Выгрузить все товары BV</a></li>	
		<li class="siteua"><a href="<?php echo $btv_aprtdrnm; ?>goods/temp.html">Замена кодов/цен</a></li>	
		<li class="siteru"><a href="<?php echo $btv_aprtdrnm; ?>goods/temp_rusite.html">Замена кодов/цен(РОС)</a></li>	
	<?php endif;?>
</ul>
<br />
<hr />
<a class="siteua" href="<?php echo $btv_aprtdrnm; ?>upprcrule" style="font:bold 14px Verdana, Arial, Helvetica, sans-serif;">
	Ценовые правила</a>
<br>
<ul class="admin_nav">
	<li class="siteia"><a href="<?php echo $btv_aprtdrnm; ?>upprcrule/?p=type">Типы ценовых правил</a></li>
	<li><a href="<?php echo $btv_aprtdrnm; ?>upprcrule/?p=variant">Варианты ценовых правил</a></li>
</ul>
<br class="siteru">
<hr class="siteru">
<a class="siteru" href="<?php echo $btv_aprtdrnm; ?>upprcrule_rusite" style="font:bold 14px Verdana, Arial, Helvetica, sans-serif;">
	Ценовые правила (РОССИЯ)</a>
<br>
<ul class="admin_nav">
	<li class="siteru"><a href="<?php echo $btv_aprtdrnm; ?>upprcrule_rusite/?p=type">Типы ценовых правил (РОССИЯ)</a></li>
</ul>
<br class="siteru">
<hr>
<ul class="admin_nav siteia">
<a href="<?php echo $btv_aprtdrnm; ?>parameters/" style="font:bold 13px Verdana, Arial, Helvetica, sans-serif;">Параметры/правила сайта</a>
</ul>
<br>
<hr />
<a href="<?php echo $btv_aprtdrnm; ?>akcii/"><b>Акции</b></a><br>
<ul class="admin_nav">
	<li><a href="<?php echo $btv_aprtdrnm; ?>akcii/?p=promocod">Промокоды</a></li>
</ul>
<br>
<hr>
<a class="siteua" href="<?php echo $btv_aprtdrnm; ?>members/" ><b>Members BV</b></a>&nbsp;&nbsp;<a  href="<?php echo $btv_aprtdrnm; ?>members/peopleadd.html" title="Add member">+</a><br>
<br class="siteru">
<hr class="siteru">
<a class="siteru" href="<?php echo $btv_aprtdrnm; ?>members/index_rusite.html" ><b>Members (РОССИЯ)</b></a>&nbsp;&nbsp;<a class="siteru" href="<?php echo $btv_aprtdrnm; ?>members/peopleadd_rusite.html" title="Add member">+</a><br>
<hr>
<br class="siteru">
<hr>
<a class="siteua" href="<?php echo $btv_aprtdrnm; ?>ordernmlog.php?limit=1000"><b>Orders NM Log</b></a><br>
<a class="siteua" href="<?php echo $btv_aprtdrnm; ?>e-orderlog.php"><b>E-Orders Log</b></a><br>
<br>

<hr class="siteru">
<a class="siteru" href="<?php echo $btv_aprtdrnm; ?>orderlog_rusite.php"><b>Orders Log (РОССИЯ)</b></a><br class="siteru">
<a class="siteru" href="<?php echo $btv_aprtdrnm; ?>ordernmlog_rusite.php"><b>Orders NM Log (РОССИЯ)</b></a><br class="siteru">
<a class="siteru" href="<?php echo $btv_aprtdrnm; ?>e-orderlog_rusite.php"><b>E-Orders Log (РОССИЯ)</b></a><br class="siteru">
<br class="siteru">
<hr>
<img src="/images/a/1.gif" width="150" height="1" alt=""><br>

<br>



</td>
<td class="nav-brd" ></td>
<!--Left col end-->