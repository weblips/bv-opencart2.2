<html>
<head>
	<meta HTTP-EQUIV="Pragma" CONTENT="no-cache">
    <META HTTP-EQUIV="Expires" CONTENT="Mon, 01 Jan 2001 00:00:01 GMT"> 
         <title>>>></title>
         <link rel="STYLESHEET" type="text/css" href="<?php echo BASE_URL; ?>.bva/style/adm.css">
</head>
<body bgcolor="#F3F3F3"><center>
<form method="post" action="<?php //if (isset($item) && $item<>1) echo '.'; echo './index.php';?>">
  <p>
 <br>
 <br>
 <br>
 <table cellpadding=5>
 <td>
 <input class="bformbtn" type="text" name="getusr" size="20" value="<?php if (isset($ausr0)) echo $ausr0;?>">
 <br>
 <input class="bformbtn" type="password" name="getwrd" size="20" value="<?php if (isset($awrd0)) echo $awrd0;?>">
 </td><td valign="middle">
 &nbsp;&nbsp;<input type="submit" name="Submit1" value=" >>> " class="yformbtn">
 </td>	
 </table>
  </p>
  </form></center>
</body></html>
