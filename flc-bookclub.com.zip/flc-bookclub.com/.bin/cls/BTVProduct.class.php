<?php
//Класс который обрабатывает акции

class BTVProduct {
	private $data = array();
	private $db;
	//static private $_instance;
	private $_arrayCategories = array();
	public function __construct() {	
		global $DB;
		$this->btv_products = 'btv_products';
		$this->btv_categories = 'btv_categories';
		$this->btv_c2t = 'btv_c2t';
		$this->btv_products_haracter = 'btv_products_haracter';
		$this->btv_products_haracter_values = 'btv_products_haracter_values';
		$this->btv_price_values = 'btv_price_values';
		$this->btv_products_images = 'btv_products_images';
		$this->db = $DB;
	}
    /*public static function getInstance() {
        if (self::$_instance === null) {
            self::$_instance = new self();  
        }
        return self::$_instance;
    }*/
    /*public function __get($name) {
        if (array_key_exists($name, $this->data)) {
            return $this->data[$name];
        } else {
			return '';
		}
	}
	public function __set($name, $value) {
		$this->data[$name] = $value;
	}*/
	
	public function getList($i, $p, $param, $order, $only_count = false) {
		if ($only_count) {
			$sql = "SELECT count(*) c ";
		} else {
			$sql = "SELECT pr.*, cat.name_ru cat_name_ru ";
		}
		$mp = array();
		$sql .= "FROM $this->btv_products pr, $this->btv_categories cat";
		$mp [] = "pr.category_id = cat.id";		
		if (is_array($param) && $param) {
			foreach ($param as $k => $v) {
				if ($k == 'pr.name') {
					if ($v) {
						$mp [] = '(pr.name_ru LIKE \'%' . $v . '%\' OR pr.name_ua LIKE \'%' . $v . '%\')';
					}
				} else {
					if ($v !== '') {
						if ($k == 'c.title') {
							$sql .= ", $this->btv_c2t c";
							$mp [] = "pr.id = c.pid";
						}
						$mp [] = "$k = '$v'";
					}
				}
			}
		}
		$sql .= ' WHERE ' . implode(' AND ', $mp);
		if ($only_count) {
			$res = $this->db->query($sql);
			return $res->fetchColumn();
		} else {
			if (is_array($order) && $order) {
				$mp = array();
				foreach ($order as $k => $v) {
					$mp [] = "$k $v";
				}
				$sql .= ' ORDER BY ' . implode(' ', $mp);
			} elseif ($order) {
				$sql .= ' ORDER BY ' . $order;
			}
			if ($i >= 0 && $p > 0) {
				$sql .= ' LIMIT ' . ($i * $p) . ',' . $p;
			}
		}
		$res = $this->db->query($sql);
		//echo $sql;
		if (!$res) {
			return;
		}
		$m = $res->fetchAll(PDO::FETCH_ASSOC);
		return $m;
	}
	
	public function getTitles($id) {
		$sql = "SELECT title FROM btv_c2t WHERE pid = " . $id;
		$res = $this->db->query($sql);	
		if (!$res) {
			return;
		}
		$m = $res->fetchAll();
		$mTitles = array();
		foreach ($m as $row) {
			$mTitles[] = $row['title'];
		}	
		return $mTitles;
	}
	public function setTitles($id, $code, $titles) {
		$sql = 'DELETE FROM `btv_c2t` WHERE `pid`=' . $id;
		//echo $sql . '<br>';
		$this->db->exec($sql);
		$titlesArray = explode(",",  trim($titles));
		//var_dump($titlesArray);
		$arWhere = array();
		foreach ($titlesArray as $t) {
			$sql = 'INSERT INTO btv_c2t SET pid = ' . $id . ', code = ' . $code . ', title = ' . $t;
			//echo $sql . '<br>';
			$this->db->exec($sql);
		}
	}
	public function getCountHaracters($id) {
		$sql = 'SELECT count(*) FROM `btv_products_haracter_values` where product_id=' . $id;
		$res = $this->db->query($sql);	
		if (!$res) {
			return;
		}
		return $res->fetchColumn();
	}	
	public function getCountPriceValues($id) {
		$sql = "SELECT count(*) FROM $this->btv_price_values WHERE product_id = " . $id;
		$res = $this->db->query($sql);	
		if (!$res) {
			return;
		}
		return $res->fetchColumn();
	}
	public function getCountImages($id) {
		$sql = "SELECT count(*) FROM $this->btv_products_images WHERE product_id = " . $id;
		$res = $this->db->query($sql);	
		if (!$res) {
			return;
		}
		return $res->fetchColumn();
	}
	public function getHaracters($id) {
		$sql = 'SELECT v.*, h.name_ru h_name_ru, h.name_ua h_name_ua FROM `' . $this->btv_products_haracter_values . '` v JOIN ' . $this->btv_products_haracter . ' h 
			ON v.haracter_id = h.id where product_id=' . $id;
		echo $sql;
		$res = $this->db->query($sql);	
		if (!$res) {
			return;
		}
		$m = $res->fetchAll(PDO::FETCH_ASSOC);
		return $m;
	}
//insert, update
	public function changeProduct($param, $id = 0) {
		$mSet = array();
		if ($param) {
			foreach ($param as $k => $v) {
				$mSet [] = $k . ' = \'' . $v . '\'';
			}
		}
		if ($id) {
			$sql = 'UPDATE';
		} else {
			$sql = 'INSERT INTO';
			$mSet[] = 'create_data = now()';
		}
		$sql .= " $this->btv_products SET " . implode(', ', $mSet);
		if ($id) {
			$sql .= ' WHERE id = ' . $id;
		}	
		//echo $sql . '<br>';
		$this->db->exec($sql);
		if (!$id) {
			return $this->db->lastInsertId();
		}
	}
	
}