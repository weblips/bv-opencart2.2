<?php

class BTVCategories {
	private $data = array();
	public $db;
	static private $_instance;
	private $_arrayCategories = array();
	public function __construct() {	
		if (!RUSITE) {
			$this->db = Registry::extract("db");
			$this->btv_categories = 'btv_categories' . RUSITE;
			$this->btv_products = 'btv_products' . RUSITE;
			//$mFieldsForMain = cachePart::check('other/fields_actmain', '', 3600, -100);
			//if (!$mFieldsForMain) {
				$res = $this->db->query("SHOW COLUMNS FROM $this->btv_categories");
				$m = $res->fetchAll(PDO::FETCH_ASSOC);
				foreach($m as $v) {
					if ($v['Field'] != 'id' && $v['Field'] != 'create_data' && $v['Field'] != 'update_data') {
						$mFieldsForMain[] = $v['Field'];
					}
				}
				//cachePart::write('other/fields_actmain', '', $mFieldsForMain, -100);
			//}
			$this->mFieldsForMain = $mFieldsForMain;			
		}
	}
    /*public static function getInstance() {
        if (self::$_instance === null) {
            self::$_instance = new self();  
        }
        return self::$_instance;
    }*/
    public function __get($name) {
        if (array_key_exists($name, $this->data)) {
            return $this->data[$name];
        } else {
			return '';
		}
	}
	public function __set($name, $value) {
		$this->data[$name] = $value;
	}
	
	
	public function getAllCategories($cur_id) {
		/*$result = array();
		$cur_id = 0;
		do {
			if ($cur_id) {
				$m = $res->fetchAll();
				//$cur_id = $row0['id'];
				foreach ($m as $row) {
					$result[$row['id']] = $row;
				}
			}
			$sql = "SELECT * FROM $this->btv_categories parent_id = $cur_id";
			$res = $this->db->query($sql);
		} while ($res);		
		foreach($m as $k => $v) {
			$this->data[$k] = $v;
		}*/
		//echo 'cur_id='.$cur_id;
		$this->recursiaCategories($cur_id);
		//echo '<pre>';	
		//$this->_arrayCategories);
		//echo '</pre>';
		return $this->_arrayCategories;

	}
	
	private function recursiaCategories($cur_id) {
		$sql = "SELECT * FROM $this->btv_categories WHERE parent_id = $cur_id ORDER BY rng DESC";
		$res = $this->db->query($sql);
		if (!$res) {
			return;
		}
		$m = $res->fetchAll();
		foreach ($m as $row) {
			$cur_id = $row['id'];
			$this->_arrayCategories[$cur_id] = $row;
			$this->recursiaCategories($cur_id);
		}	
	}
	
	public function getCategory($id) {
		$sql = "SELECT * FROM $this->btv_categories WHERE id = $id";
		$res = $this->db->query($sql);
		if (!$res) {
			return array();
		}
		$data = $res->fetch();
		foreach ($data as $f => $v) {
			$this->$f = $v;
		}
	}
	
	public function getLevelFromId($id) {
		$sql = "SELECT level FROM $this->btv_categories WHERE id = $id";
		//echo $sql;
		$res = $this->db->query($sql);
		if (!$res) {
			return;
		}
		return $res->fetchColumn();
	}
	
	public function checkCatOnParent($id) {
		$sql = "SELECT count(*) FROM $this->btv_categories WHERE parent_id = $id";
		$res = $this->db->query($sql);
		if (!$res) {
			return;
		}
		return $res->fetchColumn();
	}	
	
	public function changeCategory($id = 0) {
		$mSet = array();
		foreach ($this->mFieldsForMain as $v) {
			$mSet [] = $v . ' = \'' . $this->$v . '\'';
		}
		if ($id) {
			$sql = 'UPDATE';
		} else {
			$sql = 'INSERT INTO';
			$mSet[] = 'create_data = now()';
		}
		$sql .= " $this->btv_categories SET " . implode(', ', $mSet);
		if ($id) {
			$sql .= ' WHERE id = ' . $id;
		}	
		//echo $sql;
		$this->db->exec($sql);
		if (!$id) {
			return $this->db->lastInsertId();
		}
	}
	
	function setCategoriesSiRng($msi, $mrng) {
		if ($msi) {
			foreach ($msi as $id => $si) {
				$sql = "UPDATE $this->btv_categories SET si=$si WHERE id=$id";
				$this->db->exec($sql);
			}
		}
		if ($mrng) {
			foreach ($mrng as $id => $rng) {
				$sql = "UPDATE $this->btv_categories SET rng=$rng WHERE id=$id";
				$this->db->exec($sql);
			}
		}
	}
	
	function checkProductInCategory($cat_id) {
		$sql = "SELECT count(*) FROM $this->btv_products WHERE category_id = $cat_id";
		$res = $this->db->query($sql);
		if (!$res) {
			return true;
		}
		return $res->fetchColumn();		
	}
	
	
	function delCategory($m) {
		foreach ($m as $id) {
			$sql = "DELETE FROM $this->btv_categories WHERE id=$id";
			//echo $sql;
			$this->db->exec($sql);
		}
	}
}