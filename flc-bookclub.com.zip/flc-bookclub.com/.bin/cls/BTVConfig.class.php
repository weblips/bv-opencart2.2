<?php
class BTVConfig {
	private static $language = "ru";
	private static $controller = "index";
	public static function get($param) {
		return self::$param;
	}
}