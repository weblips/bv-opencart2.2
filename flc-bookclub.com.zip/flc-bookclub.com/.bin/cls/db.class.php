<?php
class db extends PDO{
	private static $user = "bookclub";
	private static $mgwrd = ",s,ksjntrf";
	private static $host = "localhost";
	private static $local_user = "root";
	private static $local_mgwrd = '';
	private static $local_host = "localhost";
	private static $dbnm = 'bottega';
	private static $classCounter = 0;
	public function __construct() {
		if (IF_LOCAL_SITE) {
			self::$user = self::$local_user;
			self::$mgwrd = self::$local_mgwrd;
			self::$host = self::$local_host;
		}
		$dbwrd = 'mysql:dbname=' . self::$dbnm . ';host=localhost';
		parent::__construct($dbwrd, self::$user, self::$mgwrd);
		self::$classCounter++;
	}
	public function getAccount() {
		return array('user' => self::$user, 'passwd' => self::$mgwrd, 'db' => self::$dbnm, 'host' => self::$host);
	}
	public static function getInstCount() {
		return self::$classCounter;
	}
	public function __destruct() {
		self::$classCounter--;
		/*parent::__destruct();	*/
	}
	/*public function query($sql) {
		global $queryjjtimeqarr;
		/*if (defined('SITEROOT')) {
			$filecontent = trim(file_get_contents(SITEROOT . 'myfolder/busy/find/query.txt'));
			if ($filecontent != 'empty') {
				$fp = fopen(SITEROOT . 'myfolder/busy/find/query.txt', 'w');
				fwrite($fp, date('Y-m-d H:i:s') . ' - ' . $sql . ' - ' . $_SERVER['REQUEST_URI']);
				fclose($fp);
			}
		}
		$time_start = $this->microtime_float();
		$res = parent::query($sql);
		$time_end = $this->microtime_float();
		$raznitca = $time_end - $time_start;
		$queryjjtimeqarr[]=$sql.' ('.$raznitca.')';		
		return $res;
	}*/	
	//*
	/*public function prepare($sql) {
		global $queryjjtimeqarr;
		$queryjjtimeqarr[]=$sql;//.' ('.$raznitca.')';		
		return parent::prepare($sql);
	}	//*/
	function microtime_float() 
	{ 
	   list($usec, $sec) = explode(" ", microtime()); 
	   return ((float)$usec + (float)$sec); 
	}	
}