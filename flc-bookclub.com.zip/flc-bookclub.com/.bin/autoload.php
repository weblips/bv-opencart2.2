<?php /* function is auto loaded clases */
defined('DS') or die();
if (!function_exists('__autoload')) {
	function __autoload($class_name) {
		$filename = $class_name . '.class.php';
		$file = __DIR__ . DS . 'cls' . DS . $filename;		
		if (file_exists($file) == false) return false;
		require_once $file;
	}
}