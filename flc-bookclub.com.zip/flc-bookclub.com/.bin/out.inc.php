<?php 
if ($ispg) {
	pg_close($pgdb);
} else {
	if (!$link && !$DB) @mysql_close(); else 
	{
		if ($link) mysql_close($link);
		if ($DB) $DB=null;
	}
}