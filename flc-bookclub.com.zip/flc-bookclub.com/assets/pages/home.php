<section class="section section--homepage">

	<div class="container">
		
		<div class="maincarousel">

			<div class="j-carousel">
				
				<a href="javascript:void(0);" class="maincarousel__slide">
					
					<div class="slide__image" data-imagedesk="images/placeholder/carousel-1.png" data-imagemobile="images/placeholder/carousel-1-mobile.png"></div>

				</a>

				<a href="javascript:void(0);" class="maincarousel__slide">
					
					<div class="slide__image" data-imagedesk="images/placeholder/carousel-2.png" data-imagemobile="images/placeholder/carousel-1-mobile.png"></div>

				</a>

				<a href="javascript:void(0);" class="maincarousel__slide">
					
					<div class="slide__image" data-imagedesk="images/placeholder/carousel-3.png" data-imagemobile="images/placeholder/carousel-1-mobile.png"></div>

				</a>

				<a href="javascript:void(0);" class="maincarousel__slide">
					
					<div class="slide__image" data-imagedesk="images/placeholder/carousel-4.png" data-imagemobile="images/placeholder/carousel-1-mobile.png"></div>

				</a>

			</div>

			<div class="j-carouselnav maincarousel__nav">
				<a class="nav__item text--12" href="javascript:void(0);">CURA DEI CAPELLI</a>
				<a class="nav__item text--12" href="javascript:void(0);">NOVIT&Agrave; MAKE-UP</a>
				<a class="nav__item text--12" href="javascript:void(0);">SPECIALE CORPO</a>
				<a class="nav__item text--12" href="javascript:void(0);">IDEE REGALO</a>
				<a class="nav__item text--12" href="javascript:void(0);">OFFERTE SPECIALI</a>
			</div>

		</div>

	</div>

	<div class="container noDesk">
		<?php include('modules/homepagemenu.php'); ?>
	</div>

	<div class="container">
		
		<div class="productscarousel">

			<p class="productscarousel__title c--green f--light text--22"><span class="deskOnly">STAFF’S PICK: </span>LE OFFERTE DA NON PERDERE</p>

			<div class="j-carousel__filters--products productscarousel__filters">
				<a class="productscarousel__filter text--12 c--grayDark active" href="javascript:void(0);">TUTTO</a>
				<a class="productscarousel__filter text--12 c--grayDark" href="javascript:void(0);">MAKE-UP</a>
				<a class="productscarousel__filter text--12 c--grayDark" href="javascript:void(0);">VISO</a>
				<a class="productscarousel__filter text--12 c--grayDark" href="javascript:void(0);">CORPO</a>
				<a class="productscarousel__filter text--12 c--grayDark" href="javascript:void(0);">CAPELLI</a>
				<a class="productscarousel__filter text--12 c--grayDark" href="javascript:void(0);">FRAGRANZE</a>
			</div>

			<div class="j-carousel--products">
				
				<a href="javascript:void(0);" class="productscarousel__slide">

					<div class="product product--carousel">
						<div class="product__image" style="background-image:url('images/placeholder/carouselproducts-1.png');">
							<span class="badge badge--must-have"></span>
						</div>
						<div class="product__info">
							<p class="product__title text--12 c--grayDark">
								Rossetto idratante intenso
							</p>
							<p class="product__details text--12 c--grayLight">
								Un intenso trattamento idratante che regala alle labbra un colore pieno 
							</p>
							<p class="product__prices">
								<span class="product__price product__price--old c--grayLight">€ 39,00 </span>
								<span class="product__price product__price--discount c--green">-75% </span>
								<span class="product__price product__price--current c--grayDark">€ 9,99 </span>
							</p>
						</div>
					</div>

				</a>

				<a href="javascript:void(0);" class="productscarousel__slide">

					<div class="product product--carousel">
						<div class="product__image" style="background-image:url('images/placeholder/carouselproducts-2.png');">
						</div>
						<div class="product__info">
							<p class="product__title text--12 c--grayDark">
								Rossetto idratante intenso
							</p>
							<p class="product__details text--12 c--grayLight">
								Un intenso trattamento idratante che regala alle labbra un colore pieno 
							</p>
							<p class="product__prices">
								<span class="product__price product__price--old c--grayLight">€ 39,00 </span>
								<span class="product__price product__price--discount c--green">-75% </span>
								<span class="product__price product__price--current c--grayDark">€ 9,99 </span>
							</p>
						</div>
					</div>

				</a>

				<a href="javascript:void(0);" class="productscarousel__slide">

					<div class="product product--carousel">
						<div class="product__image" style="background-image:url('images/placeholder/carouselproducts-3.png');">
						</div>
						<div class="product__info">
							<p class="product__title text--12 c--grayDark">
								Rossetto idratante intenso
							</p>
							<p class="product__details text--12 c--grayLight">
								Un intenso trattamento idratante che regala alle labbra un colore pieno 
							</p>
							<p class="product__prices">
								<span class="product__price product__price--old c--grayLight"></span>
								<span class="product__price product__price--discount c--green"></span>
								<span class="product__price product__price--current c--grayDark">€ 9,99 </span>
							</p>
						</div>
					</div>

				</a>

				<a href="javascript:void(0);" class="productscarousel__slide">

					<div class="product product--carousel">
						<div class="product__image" style="background-image:url('images/placeholder/carouselproducts-4.png');">
						</div>
						<div class="product__info">
							<p class="product__title text--12 c--grayDark">
								Rossetto idratante intenso
							</p>
							<p class="product__details text--12 c--grayLight">
								Un intenso trattamento idratante che regala alle labbra un colore pieno 
							</p>
							<p class="product__prices">
								<span class="product__price product__price--old c--grayLight">€ 39,00 </span>
								<span class="product__price product__price--discount c--green">-75% </span>
								<span class="product__price product__price--current c--grayDark">€ 9,99 </span>
							</p>
						</div>
					</div>

				</a>

				<a href="javascript:void(0);" class="productscarousel__slide">

					<div class="product product--carousel">
						<div class="product__image" style="background-image:url('images/placeholder/carouselproducts-1.png');">
						</div>
						<div class="product__info">
							<p class="product__title text--12 c--grayDark">
								Rossetto idratante intenso
							</p>
							<p class="product__details text--12 c--grayLight">
								Un intenso trattamento idratante che regala alle labbra un colore pieno 
							</p>
							<p class="product__prices">
								<span class="product__price product__price--old c--grayLight">€ 39,00 </span>
								<span class="product__price product__price--discount c--green">-75% </span>
								<span class="product__price product__price--current c--grayDark">€ 9,99 </span>
							</p>
						</div>
					</div>

				</a>

				<a href="javascript:void(0);" class="productscarousel__slide">

					<div class="product product--carousel">
						<div class="product__image" style="background-image:url('images/placeholder/carouselproducts-2.png');">
							<span class="badge badge--must-have"></span>
						</div>
						<div class="product__info">
							<p class="product__title text--12 c--grayDark">
								Rossetto idratante intenso
							</p>
							<p class="product__details text--12 c--grayLight">
								Un intenso trattamento idratante che regala alle labbra un colore pieno 
							</p>
							<p class="product__prices">
								<span class="product__price product__price--old c--grayLight">€ 39,00 </span>
								<span class="product__price product__price--discount c--green">-75% </span>
								<span class="product__price product__price--current c--grayDark">€ 9,99 </span>
							</p>
						</div>
					</div>

				</a>

			</div>

		</div>

	</div>

	<div class="container">
		
		<div class="block block--square">

			<div class="block__image" data-imagedesk="images/placeholder/block-square-1.png" data-imagemobile="images/placeholder/block-square-1.png"></div>

			<div class="block__content">
				
				<p class="f--light c--grayDark">
					<span class="content__intro c--greenDarkUltra text--14">LA SELEZIONE DEL MOMENTO</span>
					<br/>
					<span class="content__title c--green text--30">MAKE-UP TRENDS</span>
					<br/>
					<span class="content__description text--17">
						Punk, Chic, Big Eyes o Glitter?<br/>Scopri tutte le ultime tendenze e impara a truccarti come una vera make-up artist grazie  ai nostri tutorial!
					</span>
					<br/>
					<span class="content__price text--30">
						Da <span class="c--green">2,99</span> Euro
					</span>
					<br/>
					<a class="button button--outline" href="javascript:void(0);">
						SCOPRI ORA
					</a>
				</p>

			</div>

		</div>

		<div class="block block--square">

			<div class="block__image" data-imagedesk="images/placeholder/block-square-2.png" data-imagemobile="images/placeholder/block-square-2.png"></div>

			<div class="block__content">
				
				<p class="f--light c--grayDark">
					<span class="content__intro text--14">SPECIALE</span>
					<br/>
					<span class="content__title c--green text--30">CREME CORPO</span>
					<br/>
					<span class="content__description text--17">
						SIAMO LA MARCA ITALIANA PIÙ SCELTA PER LA CURA DELLA PELLE DEL VISO E DEL CORPO, SCOPRI LA NOSTRA COLLEZIONE!
					</span>
					<br/>
					<span class="content__price text--30">
						Da <span class="c--green">4,99</span> Euro
					</span>
					<br/>
					<a class="button button--outline-green c--green" href="javascript:void(0);">
						SCOPRI ORA
					</a>
				</p>

			</div>

		</div>

		<div class="block block--long">

			<div class="block__image" data-imagedesk="images/placeholder/block-long-1.png" data-imagemobile="images/placeholder/block-long-1-mobile.png"></div>

			<div class="block__content">
				
				<p class="f--light c--grayDark">
					<span class="content__intro text--14">SCEGLI IL TUO REGALO</span>
					<br/>
					<span class="content__title c--green text--30">UN OMAGGIO PER TE</span>
					<br/>
					<span class="content__description text--17">
						Scopri come ottevvvvnere la fantastica borsa mare della collezione BV 2016 in 4 fantasie diverse!
					</span>
					<br/>
					<span class="content__price text--30">
						Scegli il tuo stile!
					</span>
					<br/>
					<a class="button button--outline-green c--grayDark" href="javascript:void(0);">
						SCOPRI TUTTO
					</a>
				</p>

			</div>

		</div>

		<div class="block block--square-small">

			<div class="block__image" data-imagedesk="" data-imagemobile=""></div>

			<div class="block__content">
				
				<p class="f--light c--grayDark">
					<span class="content__intro text--14">IDEE REGALO</span>
					<br/>
					<span class="content__title c--green text--30">GIFT FINDER</span>
					<br/>
					<span class="content__description text--17">
						<img src="images/placeholder/block-square-small-1.png"><br/>
						Trova il regalo perfetto in pochi e semplici passi!
					</span>
					<br/>
					<span class="content__price text--30">
					</span>
					<br/>
					<a class="button button--outline" href="javascript:void(0);">
						COMINCIA ORA
					</a>
				</p>

			</div>

		</div>

		<div class="block block--square">

			<div class="block__image" data-imagedesk="images/placeholder/block-square-3.png" data-imagemobile="images/placeholder/block-square-3.png"></div>

			<div class="block__content">
				
				<p class="f--light c--white">
					<span class="content__intro text--14">
						<img src="images/placeholder/fb-yt.png">
						<br/><br/>
						SOCIAL CONTEST
					</span>
					<br/>
					<span class="content__title text--30">CONCORSO BV AMBASSADOR</span>
					<br/>
					<span class="content__description text--17">
						DIVENTA IL VOLTO SOCIAL DI BOTTEGA VERDE, GUADAGNA PUNTI EXTRA E RICEVI PRODOTTI SPECIALI IN ANTEPRIMA!
					</span>
					<br/>
					<a class="button button--outline-white c--white" href="javascript:void(0);">
						SCOPRI COME
					</a>
				</p>

			</div>

		</div>

		<div class="block block--square">

			<div class="block__image" data-imagedesk="images/placeholder/block-square-4.png" data-imagemobile="images/placeholder/block-square-4.png"></div>

			<div class="block__content">
				
				<p class="f--light c--white">
					<span class="content__intro text--14">
						<img src="images/placeholder/tradizione-italiana.png">
					</span>
					<br/>
					<span class="content__title text--30">DA OLTRE 40 ANNI</span>
					<br/>
					<span class="content__description text--17">
						Bottega Verde nasce come erboristeria nel 1972 a Pienza, nel cuore della Toscana più vera e naturale.<br/>
						Palazzo Massaini, uno splendido castello immerso nella campagna senese, è il luogo ispiratore dei principali ingredienti dei cosmetici Bottega Verde.
					</span>
					<br/>
					<a class="button button--outline-white c--white" href="javascript:void(0);">
						SCOPRI ORA
					</a>
				</p>

			</div>

		</div>

		<div class="block block--square-small">

			<div class="block__image" data-imagedesk="images/placeholder/block-square-small-2.png" data-imagemobile="images/placeholder/block-square-small-2.png"></div>

			<div class="block__content block__content--left">
				
				<p class="f--light c--grayDark">
					<span class="content__intro text--14">CON OGNI ORDINE<br/>TANTI VANTAGGI PER TE</span>
					<br/>
					<span class="content__title text--30">PIGIAMA SORRISI</span>
					<br/>
					<span class="content__price text--30">
						Per te a soli <span class="c--green">6,99</span> €
						<br/>
						<span class="text--14">100% cotone</span>
					</span>
					<br/>
					<a class="button button--outline-green c--grayDark" href="javascript:void(0);">
						SCOPRI COME
					</a>
				</p>

			</div>

		</div>

		<div class="block block--fidelitycard">

			<div class="block__image" data-imagedesk="images/placeholder/block-long-2.png" data-imagemobile="images/placeholder/block-long-2-mobile.png"></div>

			<div class="block__content">
				
				<p class="f--light c--grayDark">
					<span class="content__intro text--14">PI&Ugrave; COMPRI, PI&Ugrave; RISPARMI!</span>
					<br/>
					<span class="content__title c--green text--30">CARTA FEDELT&Agrave;</span>
					<br/>
					<span class="content__description text--17">
						<img class="noDesk" src="images/placeholder/carta-fedelta.png">
						<br/>
						Richiedi subito la tua carta fedeltà: <span class="c--greenDarkUltra">ONLINE</span>, <span class="c--greenDarkUltra">IN NEGOZIO</span> oppure <span class="c--greenDarkUltra">AL TELEFONO</span> e comincia subito a risparmiare!
					</span>
					<br/>
					<span class="content__price text--30">
						<span class="c--green">1 €</span> di spesa <span class="c--green"> = 1 Punto</span> fidelity
					</span>
					<br/>
					<a class="button button--outline-green c--grayDark" href="javascript:void(0);">
						RICHIEDI SUBITO
					</a>
				</p>

			</div>

		</div>

	</div>

	<div class="container deskOnly">

		<p class="container__title c--grayDark f--lightsubitalic text--30">La voce dei nostri clienti</p>

        <div class="customers customers--two-item">

            <?php
                for ($i = 1; $i <= 2; $i++) {
            ?>
                <?php include('modules/customer.php'); ?>
            <?php
                }
            ?>

        </div>

	</div>

	<div class="container deskOnly">

        <?php include('partials/contacts.php'); ?>

	</div>

	<div class="container last">

        <?php include('partials/followus.php'); ?>
		
	</div>

</section>