<div class="meu">
<a href="http://flc-bookclub.com/assets/    "> index  </a>     
<a href="http://flc-bookclub.com/assets/area-riservata.php    "> 1  </a>     
<a href="http://flc-bookclub.com/assets/cart-kids.php         "> 2       </a>     
<a href="http://flc-bookclub.com/assets/catalogo.php          "> 3        </a>     
<a href="http://flc-bookclub.com/assets/checkout-kids.php     "> 4   </a>     
<a href="http://flc-bookclub.com/assets/conferma-kids.php     "> 5   </a>     
<a href="http://flc-bookclub.com/assets/coupon.php            "> 6          </a>     
<a href="http://flc-bookclub.com/assets/dem.php               "> 7             </a>     
<a href="http://flc-bookclub.com/assets/franchising.php       "> 8     </a>     
<a href="http://flc-bookclub.com/assets/lavoraconnoi.php      "> 9    </a>     
<a href="http://flc-bookclub.com/assets/listing.php           "> 10         </a>     
<a href="http://flc-bookclub.com/assets/offerte.php           "> 11         </a>     
<a href="http://flc-bookclub.com/assets/palazzo-massaini.php  "> 12</a>     
<a href="http://flc-bookclub.com/assets/registrazione.php     "> 13   </a>     
<a href="http://flc-bookclub.com/assets/scheda.php            "> 14          </a>     
<a href="http://flc-bookclub.com/assets/storelocator.php      "> 15    </a>     
</div>
<style>
.meu {
    position: fixed;
    left: 20px;
    top: 26%;
    line-height: 20px;
	opacity: 0.3;
}
.meu:hover {
    opacity: 1;
}

.meu a {
	display: block;
	height: 20px;
	width: 20px;
	background-color: red;
	color: #fff;
	text-align: center;
	margin-bottom: 6px;
}

</style>