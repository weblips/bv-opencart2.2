<div class="breadcrumb breadcrumb--cart">

    <ol class="breadcrumb__nav list-inline list-unstyled">
        <li class="breadcrumb__item active f--light text--20">
            <a href="javascript:void(0);" class="f--light">
                IL TUO CARRELLO
            </a>
        </li>
        <li class="breadcrumb__item f--light text--20">
            PAGAMENTO
        </li>
        <li class="breadcrumb__item f--light text--20">
            CONFERMA
        </li>
    </ol>

</div>