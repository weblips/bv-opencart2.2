<div class="stars">
    <span class="star f--symbol c--green text--12">R</span>
    <span class="star f--symbol c--green text--12">R</span>
    <span class="star f--symbol c--green text--12">R</span>
    <span class="star f--symbol c--green text--12">R</span>
    <span class="star f--symbol c--green text--12">R</span>
</div>