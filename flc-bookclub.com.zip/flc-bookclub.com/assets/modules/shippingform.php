<div class="form-group column-2">
    <label for="">Nome <sup>*</sup></label>
    <input type="text" class="form-control" id="">
</div>

<div class="form-group column-2">
    <label for="">Cognome <sup>*</sup></label>
    <input type="text" class="form-control" id="">
</div>

<div class="form-group column-2">
    <label for="">Indirizzo e numero civico <sup>*</sup></label>
    <input type="text" class="form-control" id="">
</div>

<div class="form-group column-2">
    <label for="">Specifiche indirizzo <em>(frazione, interno, etc)</em> <sup>*</sup></label>
    <input type="text" class="form-control" id="">
</div>

<div class="form-group column-4">
    <label for="">Città <sup>*</sup></label>

    <div class="select-control">
        <select>
            <option>-</option>
        </select>
    </div>
</div>

<div class="form-group column-4">
    <label for="">Provincia <sup>*</sup></label>

    <div class="select-control">
        <select>
            <option>-</option>
        </select>
    </div>
</div>

<div class="form-group column-2">
    <label for="">Nazione <sup>*</sup></label>

    <div class="select-control">
        <select>
            <option>-</option>
        </select>
    </div>
</div>

<div class="form-group column-4">
    <label for="">Cap <sup>*</sup></label>
    <input type="text" class="form-control" id="">
</div>

<div class="column-4 deskOnly">&nbsp;</div>

<div class="form-group column-2">
    <label for="">Cognome campanello</label>
    <input type="text" class="form-control" id="">
</div>