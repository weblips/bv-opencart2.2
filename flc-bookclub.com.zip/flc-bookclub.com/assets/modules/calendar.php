<div class="calendar">
    <div class="calendar_header">
        <div class="calendar_header_top">
            <strong class="text--13 c--white">
                MARTEDì
            </strong>
        </div>
        <div class="calendar_header_bottom">
            <strong class="text--22 c--white">
                GENNAIO
            </strong>
            <strong class="text--54 c--white">
                26
            </strong>
            <strong class="text--22 c--white">
                2016
            </strong>
        </div>
    </div>
    <div class="calendar_content">
        <div id="datepicker" class="f--regular c--grayDark text--13"></div>
    </div>
    <div class="calendar_footer">
        <ul class="list-inline list-unstyled">
            <li>
                <a href="javascript:void(0);" class="f--semibold c--green text--13">
                    CANCEL
                </a>
            </li>
            <li>
                <a href="javascript:void(0);" class="f--semibold c--green text--13">
                    OK
                </a>
            </li>
        </ul>
    </div>
</div>