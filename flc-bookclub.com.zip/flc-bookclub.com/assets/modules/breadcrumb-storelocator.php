<div class="breadcrumb">

    <ol class="breadcrumb__nav list-unstyled list-inline">
        <li class="breadcrumb__item f--light text--14">
            <a class="f--light" href="javascript:void(0);">Home</a>
        </li>
        <li class="breadcrumb__item f--light text--14">
            <a class="f--light" href="javascript:void(0);">Negozi</a>
        </li>
        <li class="breadcrumb__item active f--light text--14">Store locator</li>
    </ol>

</div>