  <script src="scripts/vendor.js"></script>

  <script src="scripts/main.js"></script>