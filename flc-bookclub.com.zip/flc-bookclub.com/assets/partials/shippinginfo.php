<ul class="shipping__nav list-unstyled list-inline">
    <li class="shipping__item">
        <span class="icon icon--shipping text--20 deskOnly"></span>
        <span class="icon icon--shipping-black text--40 noDesk"></span>
        <span class="item__text f--regular c--grayLight text--12">
            SPEDIZIONE GRATUITA SOPRA I 35€
        </span>
    </li>
    <li class="shipping__item">
        <span class="icon icon--delivery text--20 deskOnly"></span>
        <span class="icon icon--delivery-black text--40 noDesk"></span>
        <span class="item__text f--regular c--grayLight text--12">
            CONSEGNA IN 1/3 GIORNI LAVORATIVI
        </span>
    </li>
    <li class="shipping__item">
        <span class="icon icon--product text--20 deskOnly"></span>
        <span class="icon icon--product-black text--40 noDesk"></span>
        <span class="item__text f--regular c--grayLight text--12">
            PI&Ugrave; DI 3000 PRODOTTI A CATALOGO
        </span>
    </li>
    <li class="shipping__item">
        <span class="icon icon--return text--20 deskOnly"></span>
        <span class="icon icon--return-black text--40 noDesk"></span>
        <span class="item__text f--regular c--grayLight text--12">
            RESO FACILE E VELOCE
        </span>
    </li>
</ul>