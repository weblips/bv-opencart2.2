<a href="javascript:void(0);" class="nav__tabs__item active c--green" data-tab="#my-bv-whishlist" data-tab-parent="#my-bv-prodotti-preferiti">
    WISHLIST <span class="icon icon--angle-green icon--rotate-right text--16 pull-right"></span>
</a>
<a href="javascript:void(0);" class="nav__tabs__item c--green" data-tab="#my-bv-ultimi-visti" data-tab-parent="#my-bv-prodotti-preferiti">
    ULTIMI VISTI <span class="icon icon--angle-green icon--rotate-right text--16 pull-right"></span>
</a>
<a href="javascript:void(0);" class="nav__tabs__item c--green" data-tab="#my-bv-ultimi-acquistati" data-tab-parent="#my-bv-prodotti-preferiti">
    ULTIMI ACQUISTATI <span class="icon icon--angle-green icon--rotate-right text--16 pull-right"></span>
</a>
<a href="javascript:void(0);" class="nav__tabs__item c--green" data-tab="#my-bv-consigliati" data-tab-parent="#my-bv-prodotti-preferiti">
    CONSIGLIATI <span class="icon icon--angle-green icon--rotate-right text--16 pull-right"></span>
</a>