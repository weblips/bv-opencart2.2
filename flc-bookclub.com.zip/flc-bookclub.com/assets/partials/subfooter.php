<div class="subfooter">

  <div class="owner">
    <p class="f--light text--12">Bottega Verde S.r.l. &copy; - P.IVA 00823350525</p>
  </div>

  <div class="paymethods f--light text--12">
    <p><span class="deskOnly">PAGAMENTI ACCETTATI</span> <img src="images/various/paymethods.png"> <span class="deskOnly">BONIFICO CONTRASSEGNO</span></p>
  </div>

  <div class="credits deskOnly">
    <p class="f--light text--12">CREDITS | &copy; 2016 All right reserved</p>
  </div>

</div>