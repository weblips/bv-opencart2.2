<a href="javascript:void(0);" class="nav__tabs__item active c--green" data-tab="#my-bv-recensioni-scrivi" data-tab-parent="#my-bv-recensioni">
    SCRIVI <span class="icon icon--angle-green icon--rotate-right text--16 pull-right"></span>
</a>
<a href="javascript:void(0);" class="nav__tabs__item c--green" data-tab="#my-bv-recensioni-in-approvazione" data-tab-parent="#my-bv-recensioni">
    IN APPROVAZIONE <span class="icon icon--angle-green icon--rotate-right text--16 pull-right"></span>
</a>
<a href="javascript:void(0);" class="nav__tabs__item c--green" data-tab="#my-bv-recensioni-approvate" data-tab-parent="#my-bv-recensioni">
    APPROVATE <span class="icon icon--angle-green icon--rotate-right text--16 pull-right"></span>
</a>