<a href="javascript:void(0);" class="nav__tabs__item c--green active" data-tab="#my-bv-gamification-inner" data-tab-parent="#my-bv-gamification">
    GAMIFICATION <span class="icon icon--angle-green icon--rotate-right text--16 pull-right"></span>
</a>
<a href="javascript:void(0);" class="nav__tabs__item c--green" data-tab="#my-bv-regolamento" data-tab-parent="#my-bv-gamification">
    REGOLAMENTO <span class="icon icon--angle-green icon--rotate-right text--16 pull-right"></span>
</a>
<a href="javascript:void(0);" class="nav__tabs__item c--green" data-tab="#my-bv-catalogo-premi" data-tab-parent="#my-bv-gamification">
    CATALOGO PREMI <span class="icon icon--angle-green icon--rotate-right text--16 pull-right"></span>
</a>