<div class="guarantees-purchase deskOnly">
    <h3 class="guarantees-purchase__title f--regular c--green text--20">
        GARANZIE SULL’ACQUISTO
    </h3>

    <ul class="guarantees-purchase__nav list-inline">
        <li class="guarantees-purchase__item">
            <span class="icon icon--secure-payments-green text--34"></span>
            <span class="guarantees-purchase__text f--light text--16">PAGAMENTI SICURI</span>
        </li>
        <li class="guarantees-purchase__item">
            <span class="icon icon--clock-green text--34"></span>
            <span class="guarantees-purchase__text f--light text--16">CONSEGNA IN 48/72 ORE</span>
        </li>
        <li class="guarantees-purchase__item">
            <span class="icon icon--cockade-green text--34"></span>
            <span class="guarantees-purchase__text f--light text--16">SODDISFATTI O RIMBORSATI</span>
        </li>
    </ul>
</div>