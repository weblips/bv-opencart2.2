<div class="product product--carousel">
    <div class="product__image" style="background-image:url('images/placeholder/carouselproducts-2.png');">
        <span class="badge badge--must-have"></span>
    </div>
    <div class="product__info">
        <p class="product__title text--16 c--grayDark">
            Rossetto idratante intenso
        </p>
        <a href="javascript:void(0);" class="icon icon--heart text--16 pull-left"></a>
        <p class="product__prices">
            <span class="product__price product__price--old c--grayLight">€ 39,00 </span>
            <span class="product__price product__price--discount c--green">-75% </span>
            <span class="product__price product__price--current c--grayDark">€ 9,99 </span>
        </p>

        <?php include('modules/stars.php'); ?>

    </div>
</div>

<div class="product product--carousel">
    <div class="product__image" style="background-image:url('images/placeholder/carouselproducts-2.png');">
        <img class="icon-promo" src="images/various/icon-promo.png">
    </div>
    <div class="product__info">
        <p class="product__title text--16 c--grayDark">
            Rossetto idratante intenso
        </p>
        <a href="javascript:void(0);" class="icon icon--heart text--16 pull-left"></a>
        <p class="product__prices">
            <span class="product__price product__price--old c--grayLight">€ 39,00 </span>
            <span class="product__price product__price--discount c--green">-75% </span>
            <span class="product__price product__price--current c--grayDark">€ 9,99 </span>
        </p>

        <?php include('modules/stars.php'); ?>

    </div>
</div>

<div class="product product--carousel">
    <div class="product__image" style="background-image:url('images/placeholder/carouselproducts-2.png');">
        <span class="badge badge--must-have"></span>
    </div>
    <div class="product__info">
        <p class="product__title text--16 c--grayDark">
            Rossetto idratante intenso
        </p>
        <a href="javascript:void(0);" class="icon icon--heart text--16 pull-left"></a>
        <p class="product__prices">
            <span class="product__price product__price--old c--grayLight">€ 39,00 </span>
            <span class="product__price product__price--discount c--green">-75% </span>
            <span class="product__price product__price--current c--grayDark">€ 9,99 </span>
        </p>

        <?php include('modules/stars.php'); ?>

    </div>
</div>

<div class="product product--carousel">
    <div class="product__image" style="background-image:url('images/placeholder/carouselproducts-2.png');">
    </div>
    <div class="product__info">
        <p class="product__title text--16 c--grayDark">
            Rossetto idratante intenso
        </p>
        <a href="javascript:void(0);" class="icon icon--heart text--16 pull-left"></a>
        <p class="product__prices">
            <span class="product__price product__price--old c--grayLight">€ 39,00 </span>
            <span class="product__price product__price--discount c--green">-75% </span>
            <span class="product__price product__price--current c--grayDark">€ 9,99 </span>
        </p>

        <?php include('modules/stars.php'); ?>

    </div>
</div>

<div class="clearfix"></div>

<a class="button c--white text--14" href="javascript:void(0);">CARICA PIÙ PRODOTTI</a>