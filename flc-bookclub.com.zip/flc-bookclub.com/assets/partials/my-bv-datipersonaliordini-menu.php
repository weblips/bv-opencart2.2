<a href="javascript:void(0);" class="nav__tabs__item c--green active" data-tab="#my-bv-account" data-tab-parent="#my-bv-dati-personali-ordini">
    ACCOUNT <span class="icon icon--angle-green icon--rotate-right text--16 pull-right"></span>
</a>
<a href="javascript:void(0);" class="nav__tabs__item c--green" data-tab="#my-bv-newsletter" data-tab-parent="#my-bv-dati-personali-ordini">
    NEWSLETTER <span class="icon icon--angle-green icon--rotate-right text--16 pull-right"></span>
</a>
<a href="javascript:void(0);" class="nav__tabs__item c--green" data-tab="#my-bv-beauty-profile" data-tab-parent="#my-bv-dati-personali-ordini">
    BEAUTY PROFILE <span class="icon icon--angle-green icon--rotate-right text--16 pull-right"></span>
</a>
<a href="javascript:void(0);" class="nav__tabs__item c--green" data-tab="#my-bv-ricorrenze" data-tab-parent="#my-bv-dati-personali-ordini">
    RICORRENZE <span class="icon icon--angle-green icon--rotate-right text--16 pull-right"></span>
</a>
<a href="javascript:void(0);" class="nav__tabs__item c--green" data-tab="#my-bv-archivio-ordini" data-tab-parent="#my-bv-dati-personali-ordini">
    ARCHIVIO ORDINI <span class="icon icon--angle-green icon--rotate-right text--16 pull-right"></span>
</a>