<div class="delivery-stripe noDesk">
    <div class="container">

        <p class="c--white text--14">CONSEGNA RAPIDA IN 24/48 ORE A CASA TUA!</p>

    </div>
</div>