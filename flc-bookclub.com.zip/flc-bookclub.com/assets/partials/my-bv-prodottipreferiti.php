<div class="products-tabs">

    <div class="tabs__header deskOnly">

        <div class="j-products__nav__tabs nav__tabs">

            <?php include('partials/my-bv-prodottipreferiti-menu.php'); ?>

        </div>

    </div>

    <div class="tabs__content">

        <div id="my-bv-whishlist" class="tabs__panel active" style="display: block;">
            <?php include('partials/my-bv-whishlist.php'); ?>
        </div>

        <div id="my-bv-ultimi-visti" class="tabs__panel">
            <?php include('partials/my-bv-ultimi-visti.php'); ?>
        </div>

        <div id="my-bv-ultimi-acquistati" class="tabs__panel">
            <?php include('partials/my-bv-ultimi-acquistati.php'); ?>
        </div>

        <div id="my-bv-consigliati" class="tabs__panel">
            <?php include('partials/my-bv-consigliati.php'); ?>
        </div>

    </div>

</div>