<div class="cookies">
  <p class="cookies__text c--white">Utilizziamo i cookies per migliorare il sito e l’esperienza d’acquisto. Per saperne di più sui cookies e come cambiare le impostazioni, consulta la <a href="javascript:void(0);">cookie policy</a>.</p>
  <a class="j-cookie-closer cookies__closer" href="javascript:void(0)">
    <span class="icon icon--close-x-white text--16"></span>
  </a>
</div>