<div class="columns">
  
  <ul class="column">
    <li class="column__item">
      <a class="column__title text--15" href="javascript:void(0);">MENU</a>
    </li>
    <li class="column__item">
      <a class="column__link text--12" href="javascript:void(0);">Chi siamo</a>
    </li>
    <li class="column__item">
      <a class="column__link text--12" href="javascript:void(0);">Servizio clienti</a>
    </li>
    <li class="column__item">
      <a class="column__link text--12" href="javascript:void(0);">Lavora con noi</a>
    </li>
    <li class="column__item">
      <a class="column__link text--12" href="javascript:void(0);">Negozi</a>
    </li>
    <li class="column__item">
      <a class="column__link text--12" href="javascript:void(0);">Ordini da catalogo</a>
    </li>
  </ul>

  <ul class="column">
    <li class="column__item">
      <a class="column__title text--15" href="javascript:void(0);">CATEGORIE</a>
    </li>
    <li class="column__item">
      <a class="column__link text--12" href="javascript:void(0);">Viso</a>
    </li>
    <li class="column__item">
      <a class="column__link text--12" href="javascript:void(0);">Make-up</a>
    </li>
    <li class="column__item">
      <a class="column__link text--12" href="javascript:void(0);">Bagno &amp; Corpo</a>
    </li>
    <li class="column__item">
      <a class="column__link text--12" href="javascript:void(0);">Profumi</a>
    </li>
    <li class="column__item">
      <a class="column__link text--12" href="javascript:void(0);">Idee regalo</a>
    </li>
    <li class="column__item">
      <a class="column__link text--12" href="javascript:void(0);">Capelli</a>
    </li>
    <li class="column__item">
      <a class="column__link text--12" href="javascript:void(0);">Casa</a>
    </li>
    <li class="column__item">
      <a class="column__link text--12" href="javascript:void(0);">Integratori</a>
    </li>
    <li class="column__item">
      <a class="column__link text--12" href="javascript:void(0);">Promozioni</a>
    </li>
    <li class="column__item">
      <a class="column__link text--12" href="javascript:void(0);">Tutte le linee</a>
    </li>
  </ul>

  <ul class="column">
    <li class="column__item">
      <a class="column__title text--15" href="javascript:void(0);">PROFILO CORPORATE</a>
    </li>
    <li class="column__item">
      <a class="column__link text--12" href="javascript:void(0);">Palazzo Massaini</a>
    </li>
    <li class="column__item">
      <a class="column__link text--12" href="javascript:void(0);">Natura italiana</a>
    </li>
    <li class="column__item">
      <a class="column__link text--12" href="javascript:void(0);">Ricerca</a>
    </li>
    <li class="column__item">
      <a class="column__link text--12" href="javascript:void(0);">Bellezza</a>
    </li>
  </ul>

  <ul class="column">
    <li class="column__item">
      <a class="column__title text--15" href="javascript:void(0);">AREA LEGALE</a>
    </li>
    <li class="column__item">
      <a class="column__link text--12" href="javascript:void(0);">Condizioni di Vendita</a>
    </li>
    <li class="column__item">
      <a class="column__link text--12" href="javascript:void(0);">Condizioni d’uso</a>
    </li>
    <li class="column__item">
      <a class="column__link text--12" href="javascript:void(0);">Regolamenti</a>
    </li>
    <li class="column__item">
      <a class="column__link text--12" href="javascript:void(0);">Resi &amp; rimborsi</a>
    </li>
    <li class="column__item">
      <a class="column__link text--12" href="javascript:void(0);">Temi di Spedizione</a>
    </li>
    <li class="column__item">
      <a class="column__link text--12" href="javascript:void(0);">Privacy</a>
    </li>
    <li class="column__item">
      <a class="column__link text--12" href="javascript:void(0);">Cookie</a>
    </li>
  </ul>

  <ul class="column">
    <li class="column__item">
      <a class="column__title text--15" href="javascript:void(0);">CUSTOMER CARE</a>
    </li>
    <li class="column__item">
      <a class="column__link text--12" href="javascript:void(0);">Newsletter</a>
    </li>
    <li class="column__item">
      <a class="column__link text--12" href="javascript:void(0);">Contatti</a>
    </li>
    <li class="column__item">
      <a class="column__link text--12" href="javascript:void(0);">Metodi di pagamento</a>
    </li>
    <li class="column__item">
      <a class="column__link text--12" href="javascript:void(0);">Chat</a>
    </li>
    <li class="column__item">
      <a class="column__link text--12" href="javascript:void(0);">FAQ</a>
    </li>
  </ul>

</div>