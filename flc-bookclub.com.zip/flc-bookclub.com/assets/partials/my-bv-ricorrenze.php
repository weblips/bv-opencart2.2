<h4 class="title-mobile f--regular text-14 c--green noDesk">
    RICORRENZE
</h4>

<p class="text--14">
    <strong>Intro ricorrenze</strong> loremp ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
    Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
</p>

<div class="recurrence_content">
    <div class="recurrence_row">
        <h3 class="f--regular text--14 c--green">
            RICORRENZA 1
        </h3>
        <span class="f--regular text--14">
            Scrivi qui la tua ricorrenza
        </span>
        <form class="form">

            <textarea class="form-control" rows="7"></textarea>

            <div class="recurrence_row_footer">

                <a class="datepicker-button active" href="javascript:void(0);"></a>

                <button class="button c--white text--12" href="javascript:void(0);">
                    INVIA
                </button>
            </div>
        </form>

    </div>

    <div class="recurrence_row">
        <h3 class="f--regular text--14 c--green">
            RICORRENZA 2
        </h3>
        <span class="f--regular text--14">
            Scrivi qui la tua ricorrenza
        </span>
        <form class="form">

            <textarea class="form-control" rows="7"></textarea>

            <div class="recurrence_row_footer">

                <a class="datepicker-button" href="javascript:void(0);"></a>

                <button class="button c--white text--12" href="javascript:void(0);">
                    INVIA
                </button>
            </div>
        </form>

    </div>

    <div class="recurrence_row">
        <h3 class="f--regular text--14 c--green">
            RICORRENZA 3
        </h3>
        <span class="f--regular text--14">
            Scrivi qui la tua ricorrenza
        </span>
        <form class="form">

            <textarea class="form-control" rows="7"></textarea>

            <div class="recurrence_row_footer">

                <a class="datepicker-button" href="javascript:void(0);"></a>

                <button class="button c--white text--12" href="javascript:void(0);">
                    INVIA
                </button>
            </div>
        </form>

    </div>
</div>

<div class="recurrence_calendar">

    <?php include('modules/calendar.php'); ?>

</div>