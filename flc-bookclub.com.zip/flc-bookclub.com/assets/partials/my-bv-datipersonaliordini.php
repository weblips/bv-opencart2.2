<div class="tabs__header deskOnly">

    <div class="j-my-bv-nav__tabs nav__tabs">

        <?php include('partials/my-bv-datipersonaliordini-menu.php'); ?>

    </div>

</div>

<div class="tabs__content">

    <div id="my-bv-account" class="tabs__panel active" style="display: block;">
        <?php include('partials/my-bv-account.php'); ?>
    </div>

    <div id="my-bv-newsletter" class="tabs__panel" style="display: none;">
        <?php include('partials/my-bv-newsletter.php'); ?>
    </div>

    <div id="my-bv-beauty-profile" class="tabs__panel" style="display: none;">
        <?php include('partials/my-bv-beautyprofile.php'); ?>
    </div>

    <div id="my-bv-ricorrenze" class="tabs__panel" style="display: none;">
        <?php include('partials/my-bv-ricorrenze.php'); ?>
    </div>

    <div id="my-bv-archivio-ordini" class="tabs__panel" style="display: none;">
        <?php include('partials/my-bv-archivioordini.php'); ?>
    </div>

</div>