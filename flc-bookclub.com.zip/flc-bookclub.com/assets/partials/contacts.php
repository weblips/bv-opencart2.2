<div class="contacts">
    <div class="contact">
        <p class="contact__details">
            <span class="icon icon--phone text--26"></span>
            <span class="f--semibolditalic">Customer care</span>
            <br/>
            <a class="f--lightsubitalic" href="javascript:void(0);">800 123 456 78</a>
        </p>
    </div>

    <div class="contact">
        <p class="contact__details">
            <span class="icon icon--email text--40"></span>
            <span class="f--semibolditalic">Scrivici</span>
            <br/>
            <a class="f--lightsubitalic" href="javascript:void(0);">infoshop@bottegaverde.it</a>
        </p>
    </div>

    <div class="contact">
        <p class="contact__details">
            <span class="icon icon--pin-outline text--30"></span>
            <span class="f--semibolditalic">Store Locator</span>
            <br/>
            <a class="f--lightsubitalic" href="javascript:void(0);">oltre 400 punti vendita</a>
        </p>
    </div>

    <div class="contact">
        <p class="contact__details">
            <span class="icon icon--popup text--40"></span>
            <span class="f--semibolditalic">Beauty Consultant</span>
            <br/>
            <a class="f--lightsubitalic" href="javascript:void(0);">chiedi un consiglio</a>
        </p>
    </div>
</div>