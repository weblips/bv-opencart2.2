<div class="tabs__header deskOnly">

    <div class="j-my-bv-nav__tabs nav__tabs">

        <?php include('partials/my-bv-gamification-menu.php'); ?>

    </div>

</div>

<div class="tabs__content">

    <div id="my-bv-gamification-inner" class="tabs__panel active" style="display: block;">
        <?php include('partials/my-bv-gamification-inner.php'); ?>
    </div>

    <div id="my-bv-regolamento" class="tabs__panel" style="display: none;">
        <?php include('partials/my-bv-regolamento.php'); ?>
    </div>

    <div id="my-bv-catalogo-premi" class="tabs__panel" style="display: none;">
        <?php include('partials/my-bv-catalogo-premi.php'); ?>
    </div>

</div>